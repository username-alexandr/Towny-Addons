package cc.crafto.ui.server;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class PlayerSocialStoreTest {
    @TempDir Path directory;
    @Test void ignoreSurvivesRestartAndIsDirectional() throws Exception {
        Path file=directory.resolve("players.json");UUID alice=UUID.randomUUID(),bob=UUID.randomUUID();
        try(var store=new PlayerSocialStore(file)){
            store.remember(alice,"Alice_1");store.remember(bob,"Bob_2");
            assertTrue(store.toggle(alice,bob));assertTrue(store.ignores(alice,bob));assertFalse(store.ignores(bob,alice));
        }
        try(var store=new PlayerSocialStore(file)){
            assertEquals(bob,store.find("bob_2"));assertTrue(store.ignores(alice,bob));
            assertFalse(store.toggle(alice,bob));assertFalse(store.ignores(alice,bob));
        }
    }
    @Test void rejectsNamesOutsideMinecraftIdentifierRange(){
        assertFalse(PlayerSocialStore.validName("x"));assertFalse(PlayerSocialStore.validName("bad name"));
        assertTrue(PlayerSocialStore.validName("Player_123"));
    }
}
