package cc.crafto.ui.server;

import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class CityProgressionTest {
    @Test void distantBranchesRemainHiddenUntilARequiredBuildingAdvances(){
        var deep=new CityProgression.Node("foundry","Литейная","building","Производство","",0,5,Map.of("forge",3),Map.of());
        assertFalse(CityProgression.revealed(deep,Map.of(),Map.of()));
        assertFalse(CityProgression.revealed(deep,Map.of("forge",1),Map.of()));
        assertFalse(CityProgression.ready(deep,Map.of("forge",2),Map.of()));
        assertTrue(CityProgression.ready(deep,Map.of("forge",3),Map.of()));
        assertTrue(CityProgression.revealed(deep,Map.of("forge",3),Map.of()));
        assertTrue(CityProgression.revealed(new CityProgression.Node("foundry","Литейная","building","Производство","",1,5,Map.of("forge",3),Map.of()),Map.of(),Map.of()));
    }
    @Test void researchNeedsItsBuildingsAndPreviousStudy(){
        var next=new CityProgression.Node("walls","Стены","research","Исследования","",0,3,Map.of("great_library",3),Map.of("metallurgy",1));
        assertFalse(CityProgression.revealed(next,Map.of(),Map.of()));
        assertFalse(CityProgression.revealed(next,Map.of("great_library",1),Map.of()));
        assertFalse(CityProgression.ready(next,Map.of("great_library",3),Map.of()));
        assertTrue(CityProgression.ready(next,Map.of("great_library",3),Map.of("metallurgy",1)));
        assertTrue(CityProgression.revealed(next,Map.of("great_library",3),Map.of("metallurgy",1)));
    }
    @Test void onlyImmediateLockedBuildingBranchesArePreviewed(){
        var hall=new CityProgression.Node("town_hall","Ратуша","building","Город","",0,5,Map.of(),Map.of());
        var workshop=new CityProgression.Node("workshop","Мастерская","building","Город","",0,5,Map.of("town_hall",1),Map.of());
        var foundry=new CityProgression.Node("foundry","Литейная","building","Город","",0,5,Map.of("workshop",2),Map.of());
        var nodes=List.of(hall,workshop,foundry);
        assertTrue(CityProgression.frontier(workshop,nodes,Map.of(),Map.of()));
        assertFalse(CityProgression.frontier(foundry,nodes,Map.of(),Map.of()));
        var view=new CivicView();new CityProgression.Snapshot(nodes,List.of(),"").populate(view,Map.of());
        assertEquals(2,view.tree.size());
        assertEquals("building:workshop",view.tree.get(1).getAsJsonObject().get("id").getAsString());
        assertTrue(CityProgression.frontier(foundry,nodes,Map.of("workshop",1),Map.of()));
    }
    @Test void buildingWithSeveralParentsWaitsForEveryRequiredLevel(){
        var hall=new CityProgression.Node("town_hall","Ратуша","building","Город","",1,5,Map.of(),Map.of());
        var forge=new CityProgression.Node("forge","Кузница","building","Производство","",0,5,Map.of("town_hall",1),Map.of());
        var foundry=new CityProgression.Node("foundry","Литейная","building","Производство","",0,5,Map.of("town_hall",1,"forge",2),Map.of());
        var nodes=List.of(hall,forge,foundry);
        for(var levels:List.of(Map.of("town_hall",1),Map.of("town_hall",1,"forge",1))){
            assertFalse(CityProgression.frontier(foundry,nodes,levels,Map.of()));
            var view=new CivicView();new CityProgression.Snapshot(nodes,List.of(),"").populate(view,levels);
            assertFalse(view.tree.asList().stream().anyMatch(entry->entry.getAsJsonObject().get("id").getAsString().equals("building:foundry")));
        }
        var ready=new CivicView();new CityProgression.Snapshot(nodes,List.of(),"").populate(ready,Map.of("town_hall",1,"forge",2));
        assertTrue(ready.tree.asList().stream().anyMatch(entry->entry.getAsJsonObject().get("id").getAsString().equals("building:foundry")));
        // An already built node stays visible if the server later changes its catalog.
        var built=new CityProgression.Node("foundry","Литейная","building","Производство","",1,5,foundry.buildings(),Map.of());
        assertTrue(CityProgression.revealed(built,Map.of("town_hall",1),Map.of()));
    }
    @Test void researchWithBuildingAndStudyWaitsForBoth(){
        var research=new CityProgression.Node("metallurgy","Металлургия","research","Исследования","",0,3,Map.of("forge",1),Map.of("basic_science",1));
        assertFalse(CityProgression.frontier(research,List.of(),Map.of("forge",1),Map.of()));
        assertFalse(CityProgression.frontier(research,List.of(),Map.of(),Map.of("basic_science",1)));
        assertTrue(CityProgression.revealed(research,Map.of("forge",1),Map.of("basic_science",1)));
    }
    @Test void unavailableResearchDoesNotHideBuildingBranches(){
        var hall=new CityProgression.Node("town_hall","Ратуша","building","Город","",0,5,Map.of(),Map.of());
        var view=new CivicView();new CityProgression.Snapshot(List.of(hall),List.of(),"","Исследования временно недоступны").populate(view,Map.of());
        assertEquals(1,view.tree.size());
        assertTrue(view.lines.stream().anyMatch(s->s.contains("Исследования временно недоступны")));
    }
    @Test void treeActionKeysPointOnlyAtRealServerOwnedNodes(){
        var node=new CityProgression.Node("forge","Кузница","building","Базовые","",0,5,Map.of(),Map.of());
        var view=new CivicView();new CityProgression.Snapshot(List.of(node),List.of(),"").populate(view,Map.of());
        var actions=new HashMap<String,CivicView.Action>();var json=view.json("token",actions,0,12);
        assertEquals(1,json.getAsJsonArray("tree").size());assertEquals("inspect-tree",actions.get("t0").kind());assertEquals("building:forge",actions.get("t0").id());
    }
    @Test void selectedBuildingShowsServerQuoteAndResourceRequirements(){
        var node=new CityProgression.Node("forge","Кузница","building","Производство","Куёт железо",1,3,Map.of("town_hall",1),Map.of());
        var quote=new DevelopmentView(true,"",List.of(new DevelopmentView.Building("forge","Кузница",1,3)),
            List.of(new DevelopmentView.Step("forge","Кузница",2,12500,0,List.of())),
            List.of(new DevelopmentView.Supply("iron","Железо","IRON_INGOT",false,40,5,10,25)),
            12500,0,true,true,List.of(),Map.of("forge",2));
        var view=new CivicView();new CityProgression.Snapshot(List.of(node),List.of(),"", "",Map.of("building:forge",List.of("Куёт железо")),Map.of()).populate(view,Map.of("forge",1,"town_hall",1),quote,"building:forge");
        var actions=new HashMap<String,CivicView.Action>();var json=view.json("token",actions,0,12).getAsJsonObject("treeDetail");
        assertEquals("125 монет",json.get("cost").getAsString());
        assertEquals(40,json.getAsJsonArray("materials").get(0).getAsJsonObject().get("required").getAsInt());
        assertEquals(25,json.getAsJsonArray("materials").get(0).getAsJsonObject().get("missing").getAsInt());
        assertEquals("build",actions.get("treeOpen").kind());
    }
    @Test void selectedTreeAndRealisticCatalogFitOnePayload(){
        var nodes=new ArrayList<CityProgression.Node>();
        for(int i=0;i<40;i++)nodes.add(new CityProgression.Node("node_"+i,"Производственное здание "+i,"building","Производство","Развитие города",1,5,Map.of(),Map.of()));
        var supplies=new ArrayList<DevelopmentView.Supply>();
        for(int i=0;i<16;i++)supplies.add(new DevelopmentView.Supply("item_"+i,"Строительный материал "+i,"STONE",false,100,10,20,70));
        var quote=new DevelopmentView(true,"",List.of(),List.of(),supplies,85000,0,true,true,List.of(),Map.of());
        var view=new CivicView();new CityProgression.Snapshot(nodes,List.of(),"").populate(view,Map.of(),quote,"building:node_0");
        var packet=view.json("token",new HashMap<>(),0,12);
        assertTrue(cc.crafto.ui.Protocol.encode(cc.crafto.ui.Protocol.Kind.CIVIC,packet).length<cc.crafto.ui.Protocol.MAX_BYTES);
    }
    @Test void fullCatalogIsExplicitAndHiddenNodesCannotBeOpened(){
        var root=new CityProgression.Node("town_hall","Ратуша","building","Управление","",0,5,Map.of(),Map.of());
        var locked=new CityProgression.Node("foundry","Литейная","building","Производство","",0,5,Map.of("forge",3),Map.of());
        var snapshot=new CityProgression.Snapshot(List.of(root,locked),List.of(),"");
        var normal=new CivicView();snapshot.populate(normal,Map.of());
        assertEquals(1,normal.tree.size());
        var all=new CivicView();snapshot.populate(all,Map.of(),null,"building:foundry",true);
        assertEquals(2,all.tree.size());
        assertTrue(all.tree.get(1).getAsJsonObject().get("hidden").getAsBoolean());
        var actions=new HashMap<String,CivicView.Action>();var json=all.json("token",actions,0,12);
        assertEquals("Закрыто · сначала откройте зависимости",json.getAsJsonObject("treeDetail").get("status").getAsString());
        assertFalse(json.getAsJsonObject("treeDetail").has("openAction"));
        assertFalse(actions.containsKey("treeOpen"));
    }
    @Test void fullCatalogFitsProtocolLimit(){
        var nodes=new ArrayList<CityProgression.Node>();
        for(int i=0;i<100;i++)nodes.add(new CityProgression.Node("node_"+i,"Производственное здание "+i,"building",i%2==0?"Производство":"Торговля","Развитие города",0,5,i==0?Map.of():Map.of("node_"+(i-1),1),Map.of()));
        var view=new CivicView();new CityProgression.Snapshot(nodes,List.of(),"").populate(view,Map.of(),null,"",true);
        var payload=view.json("token",new HashMap<>(),0,12);
        assertEquals(100,payload.getAsJsonArray("tree").size());
        var bytes=payload.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8).length+cc.crafto.ui.Protocol.HEADER;
        assertTrue(bytes<cc.crafto.ui.Protocol.MAX_BYTES,"Full tree packet: "+bytes+" bytes");
    }
    @Test void specializationChoiceLinksUniqueBuildingAndExplainsState(){
        var hall=new CityProgression.Node("town_hall","Ратуша","building","Управление","",3,5,Map.of(),Map.of());
        var exchange=new CityProgression.Node("trade_exchange","Торговая биржа","building","Торговля","Уникальное здание: Торговый центр.",0,5,Map.of("town_hall",3),Map.of());
        var profiles=Map.of("trade_exchange",new CitySpecialization.Profile("trade","Торговый центр","Ускоряет торговлю","trade_exchange",3));
        var waiting=new CitySpecialization.Snapshot(profiles,"",3,3,3,true,"");
        var view=new CivicView();new CityProgression.Snapshot(List.of(hall,exchange),List.of(),"","",Map.of(),Map.of(),waiting).populate(view,Map.of("town_hall",3),null,"building:trade_exchange");
        var actions=new HashMap<String,CivicView.Action>();var payload=view.json("token",actions,0,12);
        assertTrue(payload.getAsJsonArray("tree").asList().stream().anyMatch(e->e.getAsJsonObject().get("id").getAsString().equals("specialization:choice")));
        var unique=payload.getAsJsonArray("tree").asList().stream().map(e->e.getAsJsonObject()).filter(e->e.get("id").getAsString().equals("building:trade_exchange")).findFirst().orElseThrow();
        assertTrue(unique.getAsJsonArray("parents").asList().stream().anyMatch(e->e.getAsString().equals("specialization:choice")));
        assertEquals("other",unique.get("choiceState").getAsString());
        assertEquals("open-specialization",actions.get("treeOpen").kind());
        assertTrue(payload.getAsJsonObject("treeDetail").get("specialization").getAsString().contains("Торговый центр"));
        var selected=new CitySpecialization.Snapshot(profiles,"trade",3,3,3,true,"");
        var ready=new CivicView();new CityProgression.Snapshot(List.of(hall,exchange),List.of(),"","",Map.of(),Map.of(),selected).populate(ready,Map.of("town_hall",3),null,"building:trade_exchange");
        var selectedActions=new HashMap<String,CivicView.Action>();ready.json("token",selectedActions,0,12);
        assertEquals("build",selectedActions.get("treeOpen").kind());
    }
}
