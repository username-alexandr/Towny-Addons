package cc.crafto.ui.server;

import cc.crafto.ui.Protocol;
import com.google.gson.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;
import java.util.function.Consumer;

/** HTTPS server-to-support bridge. The bearer token never enters a client payload. */
final class SupportBridge {
    private static final Map<String,String> ENDPOINTS=Map.of(
        "support-status","status","support-link","link-code","support-categories","categories",
        "support-tickets","tickets","support-ticket","ticket","support-create","create","support-reply","reply");
    private final JavaPlugin plugin;
    private final HttpClient http=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).followRedirects(HttpClient.Redirect.NEVER).build();
    private final String origin,token;
    SupportBridge(JavaPlugin plugin){
        this.plugin=plugin;
        YamlConfiguration config=YamlConfiguration.loadConfiguration(plugin.getDataFolder().toPath().resolve("support.yml").toFile());
        String raw=config.getString("origin","");String key=config.getString("token","");boolean enabled=config.getBoolean("enabled",false);
        URI uri;
        try{uri=URI.create(raw);}catch(IllegalArgumentException e){uri=null;}
        if(enabled&&uri!=null&&"https".equals(uri.getScheme())&&uri.getHost()!=null&&uri.getRawUserInfo()==null
           &&(uri.getRawPath()==null||uri.getRawPath().isEmpty())&&uri.getRawQuery()==null&&uri.getRawFragment()==null&&key.length()>=32){origin=raw;token=key;}
        else {origin="";token="";if(enabled)plugin.getLogger().warning("Support integration is disabled: configure an HTTPS origin and a 32+ character token in support.yml");}
    }
    boolean configured(){return !token.isEmpty();}
    void request(Player viewer,String op,long sequence,JsonObject fields,Consumer<JsonObject> callback){
        String endpoint=ENDPOINTS.get(op);
        if(endpoint==null)return;
        if(!configured()){callback.accept(Protocol.object("op","support","action",op,"request",sequence,"success",false,"message","Поддержка на сервере ещё не настроена."));return;}
        JsonObject body=fields.deepCopy();body.addProperty("uuid",viewer.getUniqueId().toString());body.addProperty("name",viewer.getName());
        byte[] payload=body.toString().getBytes(StandardCharsets.UTF_8);
        if(payload.length>16000){callback.accept(Protocol.object("op","support","action",op,"request",sequence,"success",false,"message","Текст обращения слишком длинный."));return;}
        HttpRequest request=HttpRequest.newBuilder(URI.create(origin+"/support/api/v1/game/"+endpoint))
            .timeout(Duration.ofSeconds(8)).header("Authorization","Bearer "+token).header("Content-Type","application/json")
            .POST(HttpRequest.BodyPublishers.ofByteArray(payload)).build();
        http.sendAsync(request,HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8)).whenComplete((response,error)->{
            try{viewer.getScheduler().run(plugin,t->{
                if(!viewer.isOnline())return;
                boolean success=error==null&&response.statusCode()>=200&&response.statusCode()<300;
                JsonObject data=new JsonObject();
                if(error==null&&response.body().length()<=16000)try{data=JsonParser.parseString(response.body()).getAsJsonObject();}catch(RuntimeException ignored){}
                String message=success?"":switch(error==null?response.statusCode():0){
                    case 401->"Неверный токен связи с поддержкой.";case 403->"Привяжите аккаунт и подтвердите согласие в Telegram-боте.";
                    case 429->"Слишком много попыток. Попробуйте позже.";default->Protocol.str(data,"message","Поддержка временно недоступна.");};
                callback.accept(Protocol.object("op","support","action",op,"request",sequence,"success",success,"message",message,"data",data));
            },null);}catch(IllegalStateException ignored){}
        });
    }
}
