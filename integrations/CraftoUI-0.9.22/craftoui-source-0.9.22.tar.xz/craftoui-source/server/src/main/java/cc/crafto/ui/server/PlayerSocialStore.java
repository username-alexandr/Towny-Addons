package cc.crafto.ui.server;

import com.google.gson.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

/** Server-only identities and ignore lists. Never holds private messages or web identities. */
final class PlayerSocialStore implements AutoCloseable {
    private final Path file;
    private final ExecutorService writes=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"craftoui-profile-save");t.setDaemon(true);return t;});
    private final Map<UUID,String> names=new HashMap<>();
    private final Map<UUID,Set<UUID>> ignored=new HashMap<>();
    PlayerSocialStore(Path file) throws IOException {
        this.file=file;
        if(!Files.exists(file))return;
        JsonObject root=JsonParser.parseString(Files.readString(file)).getAsJsonObject();
        if(root.has("players"))for(var item:root.getAsJsonArray("players")){
            try{
                JsonObject row=item.getAsJsonObject();UUID id=UUID.fromString(row.get("id").getAsString());
                String name=row.get("name").getAsString();if(validName(name))names.put(id,name);
                if(row.has("ignored")){Set<UUID> list=new HashSet<>();for(var value:row.getAsJsonArray("ignored"))if(list.size()<500)list.add(UUID.fromString(value.getAsString()));ignored.put(id,list);}
            }catch(RuntimeException ignoredRow){/* A malformed row cannot discard the other players. */}
        }
    }
    static boolean validName(String name){return name!=null&&name.matches("[A-Za-z0-9_]{3,16}");}
    synchronized void remember(UUID id,String name){if(validName(name)&&!name.equals(names.put(id,name)))persist();}
    synchronized UUID find(String name){return names.entrySet().stream().filter(e->e.getValue().equalsIgnoreCase(name)).map(Map.Entry::getKey).findFirst().orElse(null);}
    synchronized String name(UUID id){return names.getOrDefault(id,"Игрок");}
    synchronized List<Map.Entry<UUID,String>> search(String query){return names.entrySet().stream().filter(e->e.getValue().toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT))).sorted(Comparator.comparing(Map.Entry::getValue,String.CASE_INSENSITIVE_ORDER)).limit(80).map(e->Map.entry(e.getKey(),e.getValue())).toList();}
    synchronized boolean ignores(UUID owner,UUID other){return ignored.getOrDefault(owner,Set.of()).contains(other);}
    synchronized boolean toggle(UUID owner,UUID other){
        if(owner.equals(other))return false;
        Set<UUID> list=ignored.computeIfAbsent(owner,id->new HashSet<>());
        boolean next;if(list.remove(other))next=false;else {if(list.size()>=500)throw new IllegalStateException("Лимит списка игнорирования достигнут.");list.add(other);next=true;}
        persist();return next;
    }
    private void persist(){
        JsonArray players=new JsonArray();for(var entry:names.entrySet()){
            JsonObject row=new JsonObject();row.addProperty("id",entry.getKey().toString());row.addProperty("name",entry.getValue());
            JsonArray list=new JsonArray();ignored.getOrDefault(entry.getKey(),Set.of()).stream().sorted().forEach(id->list.add(id.toString()));row.add("ignored",list);players.add(row);
        }
        JsonObject root=new JsonObject();root.add("players",players);String json=root.toString();
        writes.execute(()->{try{
            Files.createDirectories(file.getParent());Path temporary=file.resolveSibling(file.getFileName()+".tmp");Files.writeString(temporary,json,StandardCharsets.UTF_8);
            try{Files.move(temporary,file,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(temporary,file,StandardCopyOption.REPLACE_EXISTING);}
        }catch(IOException e){System.err.println("CraftoUI: cannot save player profiles: "+e.getMessage());}});
    }
    @Override public void close(){writes.shutdown();try{writes.awaitTermination(5,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
}
