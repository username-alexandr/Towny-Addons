package cc.crafto.ui.server;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Optional, read-only view of the Specialization addon; its API owns the actual choice. */
final class CitySpecialization {
    record Profile(String id,String name,String description,String building,int minimumBuildingLevel){}
    record Snapshot(Map<String,Profile> buildings,String selected,int townLevel,int minimumTownLevel,int minimumHallLevel,boolean known,String problem){
        static Snapshot unavailable(String reason){return new Snapshot(Map.of(),"",0,3,3,false,reason);}
        Profile forBuilding(String id){return buildings.get(id);}
        String selectedName(){return buildings.values().stream().filter(p->p.id().equals(selected)).map(Profile::name).findFirst().orElse(selected);}
    }
    private CitySpecialization(){}
    static Snapshot read(Plugin plugin,UUID town){
        if(plugin==null||!plugin.isEnabled()||town==null)return Snapshot.unavailable("Аддон специализаций недоступен");
        try{
            var profiles=config(plugin,"specializations.yml").getConfigurationSection("specializations");
            if(profiles==null)throw new IllegalArgumentException("Нет каталога специализаций");
            var byBuilding=new LinkedHashMap<String,Profile>();
            for(String id:profiles.getKeys(false)){
                var section=profiles.getConfigurationSection(id);if(section==null||!section.getBoolean("enabled",true))continue;
                String building=section.getString("unique-building","");
                if(!id.matches("[a-z0-9_-]{1,64}")||!building.matches("[a-z0-9_-]{1,64}"))continue;
                byBuilding.put(building,new Profile(id,section.getString("name",id),section.getString("description",""),building,Math.max(1,section.getInt("minimum-building-level",3))));
            }
            var settings=config(plugin,"config.yml");
            int townMinimum=Math.max(1,settings.getInt("selection.minimum-town-level",3));
            int hallMinimum=Math.max(1,settings.getInt("selection.minimum-town-hall-level",3));
            var type=Class.forName("ru.neverland.townyspecialization.api.TownySpecializationApi",false,plugin.getClass().getClassLoader());
            @SuppressWarnings({"rawtypes","unchecked"}) var registration=plugin.getServer().getServicesManager().getRegistration((Class)type);
            if(registration==null||registration.getPlugin()!=plugin)throw new IllegalStateException("API специализаций недоступен");
            var snapshot=((Optional<?>)type.getMethod("specialization",UUID.class).invoke(registration.getProvider(),town)).orElse(null);
            if(snapshot==null)return new Snapshot(Map.copyOf(byBuilding),"",0,townMinimum,hallMinimum,false,"Данные специализации ещё загружаются");
            Object state=snapshot.getClass().getMethod("state").invoke(snapshot);
            String selected=(String)state.getClass().getMethod("specialization").invoke(state);
            int townLevel=(int)snapshot.getClass().getMethod("townLevel").invoke(snapshot);
            return new Snapshot(Map.copyOf(byBuilding),selected,townLevel,townMinimum,hallMinimum,true,"");
        }catch(Exception|LinkageError ex){return Snapshot.unavailable("Данные специализаций временно недоступны");}
    }
    private static YamlConfiguration config(Plugin plugin,String name)throws IOException{
        Path path=plugin.getDataFolder().toPath().resolve(name);
        try(Reader reader=Files.exists(path)?Files.newBufferedReader(path,StandardCharsets.UTF_8):new InputStreamReader(Objects.requireNonNull(plugin.getResource(name)),StandardCharsets.UTF_8)){
            return YamlConfiguration.loadConfiguration(reader);
        }
    }
}
