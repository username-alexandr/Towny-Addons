package cc.crafto.ui.server;

import cc.crafto.ui.Protocol;
import com.google.gson.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import java.lang.reflect.*;
import java.util.*;

/** Optional MagicCosmetics 3.1.x integration, loaded from the installed plugin at runtime. */
final class MagicCosmeticsBridge {
    private final JavaPlugin host;
    MagicCosmeticsBridge(JavaPlugin host){this.host=host;}
    private Class<?> api() throws ClassNotFoundException {
        Plugin plugin=host.getServer().getPluginManager().getPlugin("MagicCosmetics");
        if(plugin==null||!plugin.isEnabled())throw new ClassNotFoundException("MagicCosmetics is not enabled");
        return plugin.getClass().getClassLoader().loadClass("com.francobm.magicosmetics.api.MagicAPI");
    }
    boolean available(){try{api();return true;}catch(ReflectiveOperationException e){return false;}}
    String equipped(Player player){
        try{
            Class<?> api=api(),slot=api.getClassLoader().loadClass("com.francobm.magicosmetics.api.CosmeticType");
            Method equipped=api.getMethod("getEquipped",org.bukkit.OfflinePlayer.class,slot);
            List<String> names=new ArrayList<>();
            for(String kind:List.of("HAT","BAG","WALKING_STICK","BALLOON")){
                @SuppressWarnings({"unchecked","rawtypes"})Object value=Enum.valueOf((Class<? extends Enum>)slot.asSubclass(Enum.class),kind);
                ItemStack item=(ItemStack)equipped.invoke(null,player,value);if(item==null)continue;
                for(Entry entry:catalog())if(entry.type().equals(kind)&&(boolean)entry.cosmetic().getClass().getMethod("isCosmetic",ItemStack.class).invoke(entry.cosmetic(),item)){
                    names.add(entry.name());break;
                }
            }
            return names.isEmpty()?"Нет":String.join(", ",names);
        }catch(ReflectiveOperationException|RuntimeException e){return "—";}
    }
    private record Entry(Object cosmetic,String id,String name,String type){}
    private List<Entry> catalog() throws ReflectiveOperationException {
        Set<?> raw=(Set<?>)api().getMethod("getCosmetics").invoke(null);
        List<Entry> result=new ArrayList<>();
        for(Object cosmetic:raw){Class<?> type=cosmetic.getClass();String id=String.valueOf(type.getMethod("getId").invoke(cosmetic));
            String kind=String.valueOf(type.getMethod("getCosmeticType").invoke(cosmetic));
            if(kind.equals("SPRAY")||(boolean)type.getMethod("isHideCosmetic").invoke(cosmetic))continue;
            result.add(new Entry(cosmetic,id,String.valueOf(type.getMethod("getName").invoke(cosmetic)),kind));
        }
        result.sort(Comparator.comparing(Entry::type).thenComparing(Entry::name));return result;
    }
    JsonArray wardrobe(Player player){
        JsonArray result=new JsonArray();try{
            Class<?> api=api();Class<?> slot=api.getClassLoader().loadClass("com.francobm.magicosmetics.api.CosmeticType");
            Method equipped=api.getMethod("getEquipped",org.bukkit.OfflinePlayer.class,slot),has=api.getMethod("hasCosmetic",Player.class,String.class);
            Map<String,ItemStack> slots=new HashMap<>();for(String kind:List.of("HAT","BAG","WALKING_STICK","BALLOON")){
                @SuppressWarnings({"unchecked","rawtypes"}) Object value=Enum.valueOf((Class<? extends Enum>)slot.asSubclass(Enum.class),kind);
                slots.put(kind,(ItemStack)equipped.invoke(null,player,value));
            }
            for(Entry entry:catalog()){
                if(!(boolean)has.invoke(null,player,entry.id()))continue;
                boolean active=slots.get(entry.type())!=null&&(boolean)entry.cosmetic().getClass().getMethod("isCosmetic",ItemStack.class).invoke(entry.cosmetic(),slots.get(entry.type()));
                result.add(Protocol.object("id",entry.id(),"name",entry.name(),"slot",entry.type(),"equipped",active));
                if(result.size()>=500)break;
            }
        }catch(ReflectiveOperationException|RuntimeException e){host.getLogger().warning("MagicCosmetics wardrobe unavailable: "+e.getClass().getSimpleName());}
        return result;
    }
    String equip(Player player,String id){
        if(id.length()>100)return "Косметика не найдена.";
        try{
            Class<?> api=api();Entry entry=catalog().stream().filter(e->e.id().equals(id)).findFirst().orElse(null);
            if(entry==null)return "Косметика не найдена.";
            if(!(boolean)api.getMethod("hasCosmetic",Player.class,String.class).invoke(null,player,id))return "Эта косметика вам не принадлежит.";
            api.getMethod("EquipCosmetic",Player.class,String.class,String.class,boolean.class).invoke(null,player,id,null,true);
            return "Косметика применена: "+entry.name();
        }catch(ReflectiveOperationException|RuntimeException e){host.getLogger().warning("MagicCosmetics equip failed: "+e.getClass().getSimpleName());return "Не удалось применить косметику.";}
    }
    String remove(Player player,String kind){
        if(!List.of("HAT","BAG","WALKING_STICK","BALLOON").contains(kind))return "Неверный слот.";
        try{
            Class<?> api=api();Class<?> slot=api.getClassLoader().loadClass("com.francobm.magicosmetics.api.CosmeticType");
            @SuppressWarnings({"unchecked","rawtypes"})Object value=Enum.valueOf((Class<? extends Enum>)slot.asSubclass(Enum.class),kind);
            api.getMethod("UnEquipCosmetic",Player.class,slot).invoke(null,player,value);return "Косметика снята.";
        }catch(ReflectiveOperationException|RuntimeException e){host.getLogger().warning("MagicCosmetics unequip failed: "+e.getClass().getSimpleName());return "Не удалось снять косметику.";}
    }
}
