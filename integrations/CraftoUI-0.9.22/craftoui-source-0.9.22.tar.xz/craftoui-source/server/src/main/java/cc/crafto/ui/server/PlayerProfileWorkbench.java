package cc.crafto.ui.server;

import com.google.gson.*;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.*;
import java.util.concurrent.TimeUnit;
import static cc.crafto.ui.Protocol.*;

/** Server-authoritative in-game profiles; no website accounts, network calls or web API. */
final class PlayerProfileWorkbench {
    static final class State {String token="";UUID selected;long sequence,lastMessage;}
    private final JavaPlugin plugin;private final PlayerSocialStore store;private final MagicCosmeticsBridge cosmetics;private final SupportBridge support;
    PlayerProfileWorkbench(JavaPlugin plugin,PlayerSocialStore store,SupportBridge support){this.plugin=plugin;this.store=store;this.support=support;cosmetics=new MagicCosmeticsBridge(plugin);}
    private void send(Player p,JsonObject body){if(p.isOnline())p.sendPluginMessage(plugin,CHANNEL,encode(Kind.PROFILE,body));}
    void open(Player viewer,State state,String name){
        if(!viewer.hasPermission("craftoui.use")||!viewer.hasPermission("craftoui.profile")){viewer.sendMessage("Профиль недоступен.");return;}
        store.remember(viewer.getUniqueId(),viewer.getName());state.token=UUID.randomUUID().toString();state.sequence=0;state.selected=viewer.getUniqueId();
        send(viewer,object("op","show","token",state.token,"theme",new JsonObject()));
        if(name!=null&&!name.isBlank())show(viewer,state,name,0);else show(viewer,state,viewer.getName(),0);
    }
    void handle(Player viewer,State state,JsonObject request){
        if(!viewer.hasPermission("craftoui.use")||!viewer.hasPermission("craftoui.profile")||state.token.isBlank()||!state.token.equals(str(request,"token","")))return;
        long sequence=integer(request,"request",-1);if(sequence<=state.sequence||sequence>1_000_000_000)return;state.sequence=sequence;
        String op=str(request,"op","");
        if(op.startsWith("support-")){
            if(!viewer.hasPermission("craftoui.support"))return;
            JsonObject fields=new JsonObject();
            for(String key:List.of("category_id","subject","summary","answers","ticket_id","text","key"))if(request.has(key))fields.add(key,request.get(key).deepCopy());
            support.request(viewer,op,sequence,fields,response->{if(state.token.equals(str(request,"token","")))try{send(viewer,response);}catch(IllegalArgumentException large){send(viewer,object("op","support","action",op,"request",sequence,"success",false,"message","Ответ поддержки слишком большой. Обратитесь к администратору."));}});return;
        }
        switch(op){
            case "list" -> list(viewer,state,str(request,"query",""),Math.clamp(integer(request,"page",0),0,100));
            case "view" -> show(viewer,state,str(request,"name",""),sequence);
            case "ignore" -> {
                UUID id=state.selected;if(id==null||id.equals(viewer.getUniqueId()))return;
                try{boolean ignored=store.toggle(viewer.getUniqueId(),id);send(viewer,object("op","notice","request",sequence,"message",ignored?"Игрок добавлен в игнор.":"Игрок удалён из игнора."));show(viewer,state,store.name(id),sequence);}
                catch(IllegalStateException ex){send(viewer,object("op","notice","request",sequence,"message",ex.getMessage()));}
            }
            case "message" -> message(viewer,state,sequence,str(request,"text",""));
            case "wardrobe" -> wardrobe(viewer,state,sequence,Math.clamp(integer(request,"page",0),0,100));
            case "equip","unequip" -> {
                if(state.selected==null||!state.selected.equals(viewer.getUniqueId()))return;
                String status=op.equals("equip")?cosmetics.equip(viewer,str(request,"id","")):cosmetics.remove(viewer,str(request,"slot",""));
                send(viewer,object("op","notice","request",sequence,"message",status));wardrobe(viewer,state,sequence,Math.clamp(integer(request,"page",0),0,100));
            }
            case "close" -> {state.token="";state.selected=null;}
            default -> {}
        }
    }
    private void list(Player viewer,State state,String query,int page){
        if(query.length()>32)return;
        var matches=store.search(query);int size=12,from=Math.min(page*size,matches.size());JsonArray entries=new JsonArray();
        for(var entry:matches.subList(from,Math.min(from+size,matches.size())))entries.add(object("name",entry.getValue(),"online",Bukkit.getPlayer(entry.getKey())!=null));
        send(viewer,object("op","list","query",query,"page",page,"pages",Math.max(1,(matches.size()+size-1)/size),"entries",entries));
    }
    private void show(Player viewer,State state,String name,long request){
        if(!PlayerSocialStore.validName(name)){send(viewer,object("op","notice","request",request,"message","Введите ник игрока."));return;}
        UUID id=store.find(name);if(id==null){send(viewer,object("op","notice","request",request,"message","Игрок не найден. Профиль появится после его первого входа."));return;}
        state.selected=id;Player target=Bukkit.getPlayer(id);
        if(target==null){send(viewer,object("op","profile","request",request,"name",store.name(id),"online",false,"own",id.equals(viewer.getUniqueId()),"ignored",store.ignores(viewer.getUniqueId(),id),"cosmetics",cosmetics.available()));return;}
        // Folia: target's live data is read only on its own entity scheduler.
        target.getScheduler().run(plugin,t->{
            Map<String,String> role=new HashMap<>();if(plugin.getServer().getPluginManager().isPluginEnabled("LuckPerms"))LuckPermsBridge.fill(target,role);
            JsonObject data=object("op","profile","request",request,"name",target.getName(),"online",true,"own",id.equals(viewer.getUniqueId()),
                "world",target.getWorld().getName(),"health",(int)Math.ceil(target.getHealth()),"food",target.getFoodLevel(),"level",target.getLevel(),"mode",target.getGameMode().name(),"group",role.getOrDefault("player.group","—"),"appearance",cosmetics.equipped(target),"ignored",store.ignores(viewer.getUniqueId(),id),"cosmetics",cosmetics.available());
            viewer.getScheduler().run(plugin,ignored->{if(viewer.isOnline()&&state.selected!=null&&state.selected.equals(id))send(viewer,data);},null);
        },()->{});
    }
    private void message(Player viewer,State state,long sequence,String text){
        UUID id=state.selected;if(id==null||id.equals(viewer.getUniqueId()))return;
        if(store.ignores(viewer.getUniqueId(),id)){send(viewer,object("op","notice","request",sequence,"message","Сначала удалите игрока из игнора."));return;}
        String clean=text.strip();if(clean.isEmpty()||clean.length()>256||clean.codePoints().anyMatch(c->Character.isISOControl(c)||c=='§')){send(viewer,object("op","notice","request",sequence,"message","Сообщение должно быть одной строкой до 256 символов."));return;}
        long now=System.nanoTime();if(now-state.lastMessage<TimeUnit.SECONDS.toNanos(2)){send(viewer,object("op","notice","request",sequence,"message","Подождите перед следующим сообщением."));return;}state.lastMessage=now;
        Player recipient=Bukkit.getPlayer(id);if(recipient==null){send(viewer,object("op","notice","request",sequence,"message","Игрок сейчас не в сети."));return;}
        recipient.getScheduler().run(plugin,t->{
            boolean delivered=recipient.isOnline()&&!store.ignores(id,viewer.getUniqueId());
            if(delivered)recipient.sendMessage("[ЛС] "+viewer.getName()+": "+clean);
            viewer.getScheduler().run(plugin,x->{if(viewer.isOnline()){if(delivered)viewer.sendMessage("[ЛС → "+store.name(id)+"] "+clean);send(viewer,object("op","notice","request",sequence,"message",delivered?"Сообщение отправлено.":"Доставка невозможна."));}},null);
        },()->{});
    }
    private void wardrobe(Player viewer,State state,long request,int page){
        if(!viewer.getUniqueId().equals(state.selected))return;
        boolean available=cosmetics.available();JsonArray all=available?cosmetics.wardrobe(viewer):new JsonArray(),items=new JsonArray();
        int from=Math.min(page*12,all.size());for(int i=from;i<Math.min(from+12,all.size());i++)items.add(all.get(i));
        send(viewer,object("op","wardrobe","request",request,"available",available,"page",page,"pages",Math.max(1,(all.size()+11)/12),"entries",items));
    }
}
