package cc.crafto.ui.client;
import cc.crafto.ui.MenuSchema;
import com.google.gson.*;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import static cc.crafto.ui.Protocol.*;
/** The selected dark or light palette can be customized by a resource pack. */
final class UiTheme {
    static JsonObject resolve(JsonObject server,String mode,boolean highContrast){
        JsonObject out=server==null?new JsonObject():server.deepCopy();
        try {
            String selected=mode.equals("light")?"light":"dark";
            try(var in=UiTheme.class.getResourceAsStream("/assets/craftoui/defaults/"+selected+".json")){
                if(in!=null)merge(out,JsonParser.parseReader(new InputStreamReader(in,StandardCharsets.UTF_8)).getAsJsonObject());
            }
            String id=selected;MenuSchema.requireId(id);
            var resource=Minecraft.getInstance().getResourceManager().getResource(Identifier.parse("craftoui:themes/"+id+".json"));
            if(resource.isPresent())try(var reader=resource.get().openAsReader()){merge(out,JsonParser.parseReader(reader).getAsJsonObject());}
        }catch(Exception e){CraftoUIClient.LOG.warn("Theme override ignored: {}",e.toString());}
        if(highContrast){
            boolean light=((color(out,"background")>>16&255)+(color(out,"background")>>8&255)+(color(out,"background")&255))>390;
            out.addProperty("text",light?"#FF101A14":"#FFFFFFFF");
            out.addProperty("muted",light?"#FF263A30":"#FFE1EDE5");
            out.addProperty("accent",light?"#FF125638":"#FFAAE8C4");
            out.addProperty("border",light?"#FF53695B":"#FF91AB9E");
        }
        return out;
    }
    static int shade(JsonObject theme,int level){
        int base=color(theme,"shade"),alpha=switch(Math.clamp(level,0,3)){case 0->0;case 1->65;case 2->130;default->190;};
        return alpha<<24|base&0x00ffffff;
    }
    private static void merge(JsonObject into,JsonObject from){validateTree(from,0);from.entrySet().forEach(e->into.add(e.getKey(),e.getValue()));}
    static int color(JsonObject theme,String key){
        String fallback=switch(key){case "text"->"#FFF1F4FA";case "muted"->"#FFADB6C7";case "accent"->"#FF54D797";case "shade"->"#A0000000";default->"#FF343B4A";};
        try{return (int)Long.parseLong(str(theme,key,fallback).substring(1),16);}catch(Exception e){return (int)Long.parseLong(fallback.substring(1),16);}
    }
}
