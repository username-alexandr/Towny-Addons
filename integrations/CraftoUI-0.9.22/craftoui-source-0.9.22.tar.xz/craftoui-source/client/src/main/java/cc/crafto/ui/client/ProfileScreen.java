package cc.crafto.ui.client;

import cc.crafto.ui.Protocol.Kind;
import com.google.gson.*;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import java.util.*;
import static cc.crafto.ui.Protocol.*;

/** In-game player profiles. The server owns all identity, message and cosmetic decisions. */
final class ProfileScreen extends PanelScreen {
    private final CraftoUIClient client;private final Screen parent;private final String token;
    private String tab="profile",name="",query="",notice="",draft="";
    private JsonObject profile=new JsonObject();private List<JsonObject> players=List.of(),wardrobe=List.of();
    private int page,pages=1,cosmeticPage,cosmeticPages=1,sequence;private boolean wardrobeAvailable,searchPending,fromPlayers;
    private boolean profileWide,profileOwn;
    private long searchDue;
    ProfileScreen(CraftoUIClient client,Screen parent,JsonObject show){super("Игровой профиль",client);this.client=client;this.parent=parent;token=str(show,"token","");}
    private void request(String op,JsonObject data){data.addProperty("op",op);data.addProperty("token",token);data.addProperty("request",++sequence);client.send(Kind.PROFILE,data);}
    void resume(int lastRequest){sequence=Math.max(sequence,lastRequest);changed();}
    void receive(JsonObject b){
        switch(str(b,"op","")){
            case "profile" -> {profile=b.deepCopy();name=str(b,"name","");if(name.equalsIgnoreCase(clientName()))tab="profile";notice="";}
            case "list" -> {page=integer(b,"page",0);pages=Math.max(1,integer(b,"pages",1));List<JsonObject> rows=new ArrayList<>();
                if(b.has("entries")&&b.get("entries").isJsonArray())for(var item:b.getAsJsonArray("entries"))if(rows.size()<12)rows.add(item.getAsJsonObject().deepCopy());players=List.copyOf(rows);searchPending=false;}
            case "wardrobe" -> {wardrobeAvailable=bool(b,"available",false);cosmeticPage=integer(b,"page",0);cosmeticPages=Math.max(1,integer(b,"pages",1));List<JsonObject> rows=new ArrayList<>();
                if(b.has("entries")&&b.get("entries").isJsonArray())for(var item:b.getAsJsonArray("entries"))if(rows.size()<200)rows.add(item.getAsJsonObject().deepCopy());wardrobe=List.copyOf(rows);}
            case "notice" -> notice=str(b,"message","");
            default -> {}
        }changed();
    }
    private String clientName(){return net.minecraft.client.Minecraft.getInstance().player==null?"":net.minecraft.client.Minecraft.getInstance().player.getName().getString();}
    private void switchTab(String next){tab=next;if(next.equals("profile")&&!fromPlayers&&!name.equalsIgnoreCase(clientName()))request("view",object("name",clientName()));resetScroll();changed();if(next.equals("players"))search();if(next.equals("wardrobe")){cosmeticPage=0;request("wardrobe",object("page",0));}}
    private void search(){searchPending=true;request("list",object("query",query,"page",page));}
    @Override protected void init(){
        begin(UiTheme.resolve(client.lastTheme,client.settings.themeMode(),client.settings.highContrast),"Игровой профиль","Игроки и действия на этом сервере","avatar");
        profileWide=false;
        tab("Профиль","avatar",0,5,tab.equals("profile")||tab.equals("message"),()->switchTab("profile"));
        tab("Игроки","search",1,5,tab.equals("players"),()->switchTab("players"));
        var wardrobeTab=tab("Гардероб","cosmetic",2,5,tab.equals("wardrobe"),()->switchTab("wardrobe"));wardrobeTab.active=bool(profile,"own",false);
        var supportTab=tab("Поддержка","inbox",3,5,false,()->client.support(this,token,sequence));supportTab.active=bool(profile,"own",false);
        tab("Документы","form",4,5,tab.equals("documents"),()->switchTab("documents"));
        footer(this::onClose,"Обновить",()->{if(tab.equals("players"))search();else if(tab.equals("wardrobe"))request("wardrobe",object("page",cosmeticPage));else if(!name.isBlank())request("view",object("name",name));});
        switch(tab){case "players"->players();case "wardrobe"->wardrobe();case "documents"->documents();case "message"->messageForm();default->profile();}
        status=notice;finish();
    }
    private void profile(){
        if(name.isBlank()){info("Загружаем профиль","Данные персонажа поступят с игрового сервера.","avatar",0);return;}
        boolean own=bool(profile,"own",false),online=bool(profile,"online",false);
        profileOwn=own;profileWide=span>=480;
        if(profileWide){
            if(own){
                int gap=10,w=(span-2*gap)/3;
                card("Гардероб","Моя косметика","cosmetic","catalog",false,0,156,w,56,()->switchTab("wardrobe"));
                card("Документы","Паспорт позже","form","catalog",false,w+gap,156,w,56,()->switchTab("documents"));
                card("Поддержка","Мои обращения","inbox","catalog",false,2*(w+gap),156,span-2*(w+gap),56,()->client.support(this,token,sequence));
            }else{
                int facts=Math.max(245,(span-10)*3/5),right=facts+10,actionWidth=span-right;
                boolean ignored=bool(profile,"ignored",false);
                if(online&&!ignored)card("Написать в ЛС","На этом сервере","form","catalog",false,right,111,actionWidth,43,()->{tab="message";resetScroll();changed();});
                card(ignored?"Убрать из игнора":"Игнорировать",ignored?"Разрешить ЛС":"Не получать ЛС","check","catalog",false,right,163,actionWidth,43,()->request("ignore",new JsonObject()));
            }
            contentHeight=Math.max(contentHeight,220);
            return;
        }
        int y=info(name,online?"В игре":"Не в игре","avatar",0);
        if(online){y=info("Персонаж","Роль: "+str(profile,"group","—")+"\nУровень: "+integer(profile,"level",0)+"\nМир: "+str(profile,"world","—")+"\nЗдоровье: "+integer(profile,"health",0)+"\nСытость: "+integer(profile,"food",0),"avatar",y);}
        if(own){int w=(span-10)/2;card("Гардероб","Косметика","cosmetic","catalog",false,0,y,w,56,()->switchTab("wardrobe"));card("Игроки","Найти профиль","search","catalog",false,w+10,y,span-w-10,56,()->switchTab("players"));}
        else{boolean ignored=bool(profile,"ignored",false);int w=(span-10)/2;
            if(online&&!ignored)card("Написать в ЛС","На сервере","form","catalog",false,0,y,w,56,()->{tab="message";resetScroll();changed();});
            card(ignored?"Убрать игнор":"Игнорировать",ignored?"Разрешить ЛС":"Не получать ЛС","check","catalog",false,w+10,y,span-w-10,56,()->request("ignore",new JsonObject()));}
    }
    private void messageForm(){
        int y=info("Сообщение игроку "+name,"Личное сообщение работает только на этом сервере. Игрок должен быть в сети.","form",0);
        input("Личное сообщение","Напишите сообщение…",draft,6,y,span-150,256,s->draft=s);
        bodyPrimary("Отправить",span-133,y,125,()->{if(!draft.isBlank()){request("message",object("text",draft));draft="";resetScroll();tab="profile";changed();}});
    }
    private void fact(GuiGraphicsExtractor g,String label,String value,int x,int y,int w){
        CivicStyle.detail(g,label,x,y,w,UiTheme.color(theme,"muted"));
        CivicStyle.text(g,value,x,y+13,w,UiTheme.color(theme,"text"));
    }
    private void drawOwnProfile(GuiGraphicsExtractor g,int y,int mx,int my){
        int gap=10,portrait=(span-gap)/3,rx=left+portrait+gap,rw=span-portrait-gap;
        int panel=UiTheme.color(theme,"panel"),accent=CivicStyle.inkAccent(theme),text=UiTheme.color(theme,"text"),border=UiTheme.color(theme,"border");
        CivicStyle.panel(g,left,y,portrait,144,panel);CivicStyle.panel(g,rx,y,rw,144,panel);
        var player=net.minecraft.client.Minecraft.getInstance().player;
        if(player!=null){
            // Use the same in-game entity preview as MenuScreen's avatar widget.
            g.pose().pushMatrix();g.pose().identity();
            InventoryScreen.extractEntityInInventoryFollowsMouse(g,left+10,y+8,left+portrait-10,y+96,
                37,0.0625f,(float)mx,(float)my,player);
            g.pose().popMatrix();
        }else CivicStyle.icon(g,"avatar",left+portrait/2-9,y+42,accent);
        g.fill(left+14,y+99,left+portrait-14,y+100,border);
        CivicStyle.text(g,name,left+14,y+106,portrait-28,text);
        CivicStyle.detail(g,bool(profile,"online",false)?"● В игре":"○ Не в игре",left+14,y+125,portrait-28,accent);
        CivicStyle.text(g,"Персонаж",rx+14,y+12,rw-28,text);
        g.fill(rx+14,y+33,rx+rw-14,y+34,border);
        int cell=(rw-28)/3;
        fact(g,"Роль",str(profile,"group","—"),rx+14,y+44,cell-8);
        fact(g,"Уровень",bool(profile,"online",false)?Integer.toString(integer(profile,"level",0)):"—",rx+14+cell,y+44,cell-8);
        fact(g,"Мир",str(profile,"world","—"),rx+14+2*cell,y+44,cell-8);
        g.fill(rx+14,y+91,rx+rw-14,y+92,border);
        fact(g,"Здоровье",bool(profile,"online",false)?Integer.toString(integer(profile,"health",0)):"—",rx+14,y+100,cell-8);
        fact(g,"Сытость",bool(profile,"online",false)?Integer.toString(integer(profile,"food",0)):"—",rx+14+cell,y+100,cell-8);
        fact(g,"Режим",str(profile,"mode","—"),rx+14+2*cell,y+100,cell-8);
    }
    private void drawOtherProfile(GuiGraphicsExtractor g,int y){
        int gap=10,facts=Math.max(245,(span-gap)*3/5),right=left+facts+gap;
        int panel=UiTheme.color(theme,"panel"),accent=CivicStyle.inkAccent(theme),text=UiTheme.color(theme,"text"),muted=UiTheme.color(theme,"muted"),border=UiTheme.color(theme,"border");
        CivicStyle.panel(g,left,y,span,75,panel);
        CivicStyle.icon(g,"avatar",left+14,y+15,accent);
        CivicStyle.text(g,name,left+43,y+15,span-58,text);
        CivicStyle.detail(g,bool(profile,"online",false)?"● В игре":"○ Не в игре",left+43,y+40,span-58,accent);
        CivicStyle.panel(g,left,y+85,facts,130,panel);
        CivicStyle.text(g,"О персонаже",left+14,y+96,facts-28,text);
        g.fill(left+14,y+118,left+facts-14,y+119,border);
        String[] labels={"Роль","Уровень","Мир","Косметика"};
        String[] values={str(profile,"group","—"),bool(profile,"online",false)?Integer.toString(integer(profile,"level",0)):"—",str(profile,"world","—"),str(profile,"appearance","—")};
        for(int i=0;i<labels.length;i++){
            int row=y+126+i*20;
            CivicStyle.detail(g,labels[i],left+14,row,facts/2-16,muted);
            CivicStyle.text(g,values[i],left+facts/2,row,facts/2-14,text);
            if(i<3)g.fill(left+14,row+15,left+facts-14,row+16,CivicStyle.mix(panel,border,35));
        }
        CivicStyle.text(g,"Связаться",right+12,y+93,span-facts-gap-24,text);
        if(!bool(profile,"online",false))CivicStyle.detail(g,"Игрок не в сети — ЛС недоступно",right+12,y+135,span-facts-gap-24,muted);
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mx,int my,float delta){
        super.extractRenderState(g,mx,my,delta);
        if(!profileWide||!tab.equals("profile")||name.isBlank())return;
        g.nextStratum();g.enableScissor(left,bodyTop,left+span,bottom);
        if(profileOwn)drawOwnProfile(g,bodyTop-scroll,mx,my);else drawOtherProfile(g,bodyTop-scroll);
        g.disableScissor();
    }
    private void players(){
        input("Поиск игрока","Ник игрока…",query,6,0,span-20,32,s->{query=s;page=0;searchDue=System.nanoTime()+300_000_000L;});
        int y=37,cols=columns(170,3),w=cellWidth(cols);
        if(players.isEmpty())info(searchPending?"Ищем игроков":"Ничего не найдено",searchPending?"Ожидаем ответ сервера.":"Профили появляются после первого входа игрока на сервер.","search",y);
        for(int i=0;i<players.size();i++){
            JsonObject row=players.get(i);String playerName=str(row,"name","");
            card(playerName,bool(row,"online",false)?"В игре":"Не в игре","avatar","catalog",false,i%cols*(w+10),y+i/cols*63,w,56,()->{fromPlayers=true;request("view",object("name",playerName));tab="profile";resetScroll();changed();});
        }
        pager(page,pages,()->{page--;search();},()->{page++;search();});
    }
    private void wardrobe(){
        if(!bool(profile,"own",false)){info("Это чужой профиль","Изменять косметику может только владелец персонажа.","cosmetic",0);return;}
        if(!wardrobeAvailable){info("Гардероб недоступен","Для смены косметики нужен MagicCosmetics на этом сервере.","cosmetic",0);return;}
        int cols=columns(180,3),w=cellWidth(cols);
        if(wardrobe.isEmpty())info("Пока нет доступной косметики","Приобретённые предметы MagicCosmetics появятся здесь.","cosmetic",0);
        for(int i=0;i<wardrobe.size();i++){
            JsonObject item=wardrobe.get(i);String id=str(item,"id",""),slot=str(item,"slot",""),label=str(item,"name",id);boolean active=bool(item,"equipped",false);
            card(label,(active?"Надето · ":"Надеть · ")+slot,"cosmetic","catalog",active,i%cols*(w+10),i/cols*63,w,56,()->request(active?"unequip":"equip",active?object("slot",slot,"page",cosmeticPage):object("id",id,"page",cosmeticPage)));
        }
        pager(cosmeticPage,cosmeticPages,()->request("wardrobe",object("page",cosmeticPage-1)),()->request("wardrobe",object("page",cosmeticPage+1)));
    }
    private void documents(){info("Документы персонажа","Раздел подготовлен для будущих игровых документов, включая паспорт. Сейчас документы не выдаются и не показываются.","form",0);}
    @Override public void tick(){if(searchDue>0&&System.nanoTime()>=searchDue){searchDue=0;search();}synchronizeWidgets();}
    @Override public void onClose(){if(tab.equals("message")||tab.equals("documents")||tab.equals("wardrobe")){switchTab("profile");return;}if(fromPlayers&&tab.equals("profile")){fromPlayers=false;switchTab("players");return;}request("close",new JsonObject());if(parent instanceof MenuScreen menu)menu.suspended=false;net.minecraft.client.Minecraft.getInstance().gui.setScreen(parent);}
    @Override public boolean isInGameUi(){return true;}
}
