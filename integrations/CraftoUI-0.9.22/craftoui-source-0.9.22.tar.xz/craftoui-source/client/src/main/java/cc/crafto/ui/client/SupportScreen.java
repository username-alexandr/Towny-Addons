package cc.crafto.ui.client;

import cc.crafto.ui.Protocol.Kind;
import com.google.gson.*;
import java.util.*;
import static cc.crafto.ui.Protocol.*;

/** In-game support: the server sends authenticated requests; this screen holds no API secret. */
final class SupportScreen extends PanelScreen {
    private final CraftoUIClient client;private final ProfileScreen parent;private final String token;
    private int sequence;private String stage="home",notice="",error="",code="",subject="",summary="",reply="",createKey="",replyKey="";
    private boolean linked,consent,loaded,requested;
    private List<JsonObject> categories=List.of(),tickets=List.of(),messages=List.of();
    private JsonObject category,ticket;private final JsonObject answers=new JsonObject();
    SupportScreen(CraftoUIClient client,ProfileScreen parent,String token,int sequence){
        super("Поддержка",client);this.client=client;this.parent=parent;this.token=token;this.sequence=sequence;
    }
    private void request(String op,JsonObject body){body.addProperty("op",op);body.addProperty("token",token);body.addProperty("request",++sequence);client.send(Kind.PROFILE,body);}
    void receive(JsonObject response){
        if(!str(response,"op","").equals("support"))return;
        if(!bool(response,"success",false)){notice=str(response,"message","Поддержка временно недоступна.");if(str(response,"action","").equals("support-status")){loaded=true;error=notice;}changed();return;}
        JsonObject data=response.has("data")&&response.get("data").isJsonObject()?response.getAsJsonObject("data"):new JsonObject();
        switch(str(response,"action","")){
            case "support-status" -> {
                loaded=true;error="";linked=bool(data,"linked",false);consent=bool(data,"consent",false);
                if(linked&&consent){code="";request("support-tickets",new JsonObject());request("support-categories",new JsonObject());}
                else stage="home";
            }
            case "support-link" -> {code=str(data,"code","");notice="Код действует 10 минут. Отправьте его боту командой /link.";}
            case "support-categories" -> {List<JsonObject> rows=new ArrayList<>();if(data.has("categories"))for(var entry:data.getAsJsonArray("categories"))if(rows.size()<40)rows.add(entry.getAsJsonObject().deepCopy());categories=List.copyOf(rows);}
            case "support-tickets" -> {List<JsonObject> rows=new ArrayList<>();if(data.has("tickets"))for(var entry:data.getAsJsonArray("tickets"))if(rows.size()<20)rows.add(entry.getAsJsonObject().deepCopy());tickets=List.copyOf(rows);}
            case "support-ticket" -> {ticket=data.getAsJsonObject("ticket").deepCopy();List<JsonObject> rows=new ArrayList<>();if(data.has("messages"))for(var entry:data.getAsJsonArray("messages"))if(rows.size()<12)rows.add(entry.getAsJsonObject().deepCopy());messages=List.copyOf(rows);stage="detail";}
            case "support-create" -> {notice="Обращение "+str(data,"number","")+" создано.";subject="";summary="";answers.keySet().clear();createKey="";stage="tickets";request("support-tickets",new JsonObject());}
            case "support-reply" -> {notice="Ответ отправлен.";reply="";replyKey="";if(ticket!=null)request("support-ticket",object("ticket_id",integer(ticket,"id",0)));}
            default -> {}
        }
        resetScroll();changed();
    }
    @Override protected void init(){
        begin(UiTheme.resolve(client.lastTheme,client.settings.themeMode(),client.settings.highContrast),"Поддержка NeverLand","Обращения без перехода на сайт","inbox");noTabs();
        if(!requested){requested=true;request("support-status",new JsonObject());}
        footer(this::onClose,"Обновить",this::refresh);
        if(!loaded){info("Проверяем привязку","Связываемся с поддержкой через игровой сервер.","inbox",0);}
        else if(!error.isBlank())info("Поддержка недоступна",error+"\nПроверьте подключение или попробуйте позже.","inbox",0);
        else if(!linked)link();
        else if(!consent)info("Подтвердите условия","Откройте @neverland_support_bot, примите действующие условия и нажмите «Обновить» здесь.","inbox",0);
        else switch(stage){case "categories"->categories();case "form"->form();case "tickets"->tickets();case "detail"->detail();default->home();}
        status=notice;finish();
    }
    private void link(){
        int y=info("Привязка к поддержке",code.isBlank()?"Получите код здесь и отправьте боту @neverland_support_bot команду /link КОД. Сайт открывать не нужно.":"Код: "+code+"\nВ Telegram-боте: /link "+code+"\nПосле ответа бота нажмите «Обновить».","inbox",0);
        bodyPrimary("Получить новый код",0,y,Math.min(190,span-8),()->request("support-link",new JsonObject()));
    }
    private void home(){
        int y=info("Как получить помощь","Выберите категорию и опишите проблему. Ответы сотрудников появятся здесь и в Telegram-боте.","inbox",0);
        int w=(span-18)/2;
        card("Новое обращение","Описать вопрос для поддержки","form","catalog",false,0,y,w,64,()->go("categories"));
        card("Мои обращения","Статусы и переписка","orders","catalog",false,w+10,y,span-w-18,64,()->{go("tickets");request("support-tickets",new JsonObject());});
    }
    private void go(String next){stage=next;resetScroll();changed();}
    private void refresh(){
        if(stage.equals("detail")&&ticket!=null)request("support-ticket",object("ticket_id",integer(ticket,"id",0)));
        else if(stage.equals("tickets"))request("support-tickets",new JsonObject());
        else if(stage.equals("categories")||stage.equals("form"))request("support-categories",new JsonObject());
        else request("support-status",new JsonObject());
    }
    private void categories(){
        if(categories.isEmpty()){info("Загружаем категории","Если список не появился, нажмите «Обновить».","form",0);return;}
        int cols=columns(180,2),w=cellWidth(cols);
        for(int i=0;i<categories.size();i++){
            JsonObject row=categories.get(i);card(str(row,"name","Раздел"),str(row,"description",""),"form","catalog",false,i%cols*(w+10),i/cols*70,w,64,()->{
                category=row;subject="";summary="";createKey="";answers.keySet().clear();go("form");
            });
        }
    }
    private void form(){
        if(category==null){go("categories");return;}
        int y=info(str(category,"name","Обращение"),str(category,"description","Опишите вопрос для поддержки."),"form",0);
        y=info("Тема","Короткое название обращения.","form",y);
        input("Тема","Например: проблема с меню…",subject,6,y,span-20,180,s->subject=s);y+=40;
        y=info("Описание","Что произошло и какую помощь вы ждёте?", "form",y);
        input("Описание","Опишите ситуацию…",summary,6,y,span-20,3500,s->summary=s);y+=42;
        if(category.has("questions"))for(var item:category.getAsJsonArray("questions")){
            JsonObject question=item.getAsJsonObject();String key=str(question,"key","");boolean required=bool(question,"required",false);
            String choices="";
            if(question.has("options")&&question.getAsJsonArray("options").size()>0){List<String> options=new ArrayList<>();for(var option:question.getAsJsonArray("options"))options.add(option.getAsString());choices="\nВарианты: "+String.join(" · ",options);}
            y=info(str(question,"prompt",key),(required?"Обязательный ответ":"Можно пропустить")+choices,"form",y);
            input(key,"Введите ответ…",str(answers,key,""),6,y,span-20,1000,s->answers.addProperty(key,s));y+=40;
        }
        bodyPrimary("Отправить обращение",0,y,span-8,()->{
            if(summary.isBlank()){notice="Добавьте описание обращения.";changed();return;}
            if(createKey.isBlank())createKey=UUID.randomUUID().toString();
            request("support-create",object("category_id",integer(category,"id",0),"subject",subject,"summary",summary,"answers",answers,"key",createKey));
        });
    }
    private void tickets(){
        int cols=columns(185,2),w=cellWidth(cols);
        if(tickets.isEmpty())info("Обращений пока нет","Создайте новое обращение, если нужна помощь.","orders",0);
        for(int i=0;i<tickets.size();i++){
            JsonObject row=tickets.get(i);int id=integer(row,"id",0);
            card(str(row,"number","Обращение"),str(row,"subject","")+" · "+str(row,"status",""),"orders","catalog",false,i%cols*(w+10),i/cols*72,w,66,()->request("support-ticket",object("ticket_id",id)));
        }
        int y=((tickets.size()+cols-1)/cols)*72+10;
        bodyPrimary("Новое обращение",0,y,Math.min(185,span-8),()->go("categories"));
    }
    private void detail(){
        if(ticket==null){go("tickets");return;}
        int y=info(str(ticket,"number","Обращение")+" · "+str(ticket,"status",""),"Категория: "+str(ticket,"category","—")+"\nТема: "+str(ticket,"subject","—")+"\nОписание: "+str(ticket,"summary",""),"orders",0);
        for(var message:messages)y=info(str(message,"sender","").equals("STAFF")?"Ответ поддержки":"Ваше сообщение",str(message,"text","—"),"form",y);
        if(!List.of("CLOSED","RESOLVED","REJECTED").contains(str(ticket,"status",""))){
            y=info("Ответить","Сообщение появится в обращении и у команды поддержки.","form",y);
            input("Ответ","Напишите сообщение…",reply,6,y,span-20,3500,s->reply=s);y+=40;
            bodyPrimary("Отправить ответ",0,y,span-8,()->{
                if(reply.isBlank())return;
                if(replyKey.isBlank())replyKey=UUID.randomUUID().toString();
                request("support-reply",object("ticket_id",integer(ticket,"id",0),"text",reply,"key",replyKey));
            });
        }
    }
    @Override public void tick(){synchronizeWidgets();}
    @Override public void onClose(){
        if(!stage.equals("home")){go(switch(stage){case "form"->"categories";case "detail"->"tickets";default->"home";});return;}
        parent.resume(sequence);net.minecraft.client.Minecraft.getInstance().gui.setScreen(parent);
    }
    @Override public boolean isInGameUi(){return true;}
}
