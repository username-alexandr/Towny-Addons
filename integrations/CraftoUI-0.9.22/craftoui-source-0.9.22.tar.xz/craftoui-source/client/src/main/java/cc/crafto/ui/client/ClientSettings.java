package cc.crafto.ui.client;
import cc.crafto.ui.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;

final class ClientSettings {
    float scale=1;
    boolean blur=false,contractsHud=true,animations=true,darkTheme=false;
    String themeMode="dark"; // Old server-theme preferences migrate to dark.
    boolean highContrast,treeRemember=true;
    int textSize,density,shadeLevel=2,blurLevel=-1,treeLines=1;
    float treeZoom=.83f,treePanX=.43f,treePanY=.53f;
    float contractsScale=1;
    Map<String,PersonalPreferences> profiles=new LinkedHashMap<>();
    private static final Path FILE=FabricLoader.getInstance().getConfigDir().resolve("craftoui.json");
    static ClientSettings load(){
        try{if(Files.exists(FILE)&&Files.size(FILE)<1024*1024){ClientSettings s=Protocol.JSON.fromJson(Files.readString(FILE),ClientSettings.class);if(s!=null){
            s.contractsScale=Float.isFinite(s.contractsScale)?Math.clamp(s.contractsScale,.65f,1.3f):1;
            s.scale=MenuScale.normalized(s.scale);
            s.themeMode="light".equals(s.themeMode)?"light":"dark";
            s.textSize=Math.clamp(s.textSize,0,1);s.density=Math.clamp(s.density,0,1);
            s.shadeLevel=Math.clamp(s.shadeLevel,0,3);s.blurLevel=s.blurLevel<0?(s.blur?2:0):Math.clamp(s.blurLevel,0,3);
            s.treeLines=Math.clamp(s.treeLines,0,2);
            s.treeZoom=Float.isFinite(s.treeZoom)?Math.clamp(s.treeZoom,.38f,2.25f):.83f;
            s.treePanX=Float.isFinite(s.treePanX)?Math.clamp(s.treePanX,-4f,5f):.43f;
            s.treePanY=Float.isFinite(s.treePanY)?Math.clamp(s.treePanY,-4f,5f):.53f;
            if(s.profiles==null)s.profiles=new LinkedHashMap<>();
            s.profiles.entrySet().removeIf(e->e.getKey().length()>256||e.getValue()==null);
            while(s.profiles.size()>32)s.profiles.remove(s.profiles.keySet().iterator().next());
            s.profiles.values().forEach(p->{p.sanitize();p.scale=MenuScale.normalized(p.scale);});return s;
        }}}catch(Exception e){CraftoUIClient.LOG.warn("Cannot read CraftoUI settings; defaults used",e);}
        return new ClientSettings();
    }
    String themeMode(){return "light".equals(themeMode)?"light":"dark";}
    int blurLevel(){return blurLevel<0?(blur?2:0):blurLevel;}
    int blurRadius(){return switch(blurLevel()){case 1->2;case 2->5;case 3->10;default->0;};}
    PersonalPreferences profile(String key){
        PersonalPreferences p=profiles.get(key);if(p!=null)return p;
        while(profiles.size()>=32)profiles.remove(profiles.keySet().iterator().next());
        p=new PersonalPreferences();p.scale=MenuScale.normalized(contractsScale);profiles.put(key,p);return p;
    }
    /** A display-only draft: never share mutable per-player profiles with the preview. */
    ClientSettings preview(){ClientSettings copy=new ClientSettings();copy.applyAppearance(this);return copy;}
    void applyAppearance(ClientSettings source){
        themeMode=source.themeMode();highContrast=source.highContrast;textSize=source.textSize;density=source.density;
        scale=source.scale;shadeLevel=source.shadeLevel;blurLevel=source.blurLevel();blur=blurLevel>0;
        animations=source.animations;treeRemember=source.treeRemember;treeLines=source.treeLines;contractsHud=source.contractsHud;
    }
    boolean sameAppearance(ClientSettings other){
        return themeMode().equals(other.themeMode())&&highContrast==other.highContrast&&textSize==other.textSize&&density==other.density
            &&scale==other.scale&&shadeLevel==other.shadeLevel&&blurLevel()==other.blurLevel()&&animations==other.animations
            &&treeRemember==other.treeRemember&&treeLines==other.treeLines&&contractsHud==other.contractsHud;
    }
    private static CompletableFuture<Void> saves=CompletableFuture.completedFuture(null);
    synchronized void save(){
        String json=Protocol.JSON.toJson(this);
        saves=saves.handle((v,e)->null).thenRunAsync(()->{
            try{Files.createDirectories(FILE.getParent());Path temp=FILE.resolveSibling("craftoui.json.tmp");Files.writeString(temp,json);
                try{Files.move(temp,FILE,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(temp,FILE,StandardCopyOption.REPLACE_EXISTING);}
            }catch(Exception e){CraftoUIClient.LOG.warn("Cannot save CraftoUI settings",e);}
        });
    }
}
