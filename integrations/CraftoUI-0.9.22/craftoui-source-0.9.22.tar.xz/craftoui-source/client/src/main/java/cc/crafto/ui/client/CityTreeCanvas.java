package cc.crafto.ui.client;

import cc.crafto.ui.CityTreeLayout;
import com.google.gson.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Font;
import java.util.*;
import static cc.crafto.ui.Protocol.*;

/** Full-screen, camera-driven graph; data and actions are supplied by the Folia plugin. */
final class CityTreeCanvas {
    private static final List<String> SECTORS=List.of("Управление","Производство","Торговля","Инфраструктура","Оборона","Наука","Культура","Энергия","Исследования");
    private static final int[] BRANCH_COLORS={0xFFD0A66E,0xFFDF936E,0xFF68C4AC,0xFF8CB7E8,0xFFE28A91,0xFFB29AE5,0xFFE2AFD3,0xFFE1D07E,0xFF8CD1DC};
    private record Link(String parent,String child,boolean choice){}
    private final Map<String,JsonObject> nodes=new LinkedHashMap<>();
    private Map<String,CityTreeLayout.Point> positions=Map.of();
    private List<Link> links=List.of();private int largestRing;private JsonArray previousGraph;
    private double zoom=.83,panX,panY;private boolean positioned,dragging,showAll;private String selected="",filter="Все",branch="Все";
    private int detailScroll;
    void update(JsonArray graph,String selection){update(graph,selection,false);}
    void update(JsonArray graph,String selection,boolean all){
        showAll=all;
        if(graph==previousGraph){
            if(!Objects.equals(selected,selection))detailScroll=0;
            selected=nodes.containsKey(selection)?selection:"";
            return;
        }
        previousGraph=graph;
        nodes.clear();var input=new ArrayList<CityTreeLayout.Node>();
        if(graph!=null)for(var element:graph){JsonObject item=element.getAsJsonObject();String id=str(item,"id","");if(id.isBlank())continue;
            nodes.put(id,item);var parents=new ArrayList<String>();if(item.has("parents"))for(var parent:item.getAsJsonArray("parents"))parents.add(parent.getAsString());
            input.add(new CityTreeLayout.Node(id,str(item,"category","Город"),parents));
        }
        positions=CityTreeLayout.arrange(input);
        var connected=new ArrayList<Link>();
        for(var entry:nodes.entrySet())if(entry.getValue().has("parents"))
            for(var parent:entry.getValue().getAsJsonArray("parents")){
                String id=parent.getAsString();
                if(nodes.containsKey(id)&&positions.containsKey(id)&&positions.containsKey(entry.getKey()))
                    connected.add(new Link(id,entry.getKey(),id.startsWith("specialization:")));
            }
        links=List.copyOf(connected);
        largestRing=positions.values().stream().mapToInt(CityTreeLayout.Point::tier).max().orElse(0);
        if(!Objects.equals(selected,selection))detailScroll=0;
        selected=nodes.containsKey(selection)?selection:"";
    }
    String filter(){return filter;}
    void filter(String next){filter=next;}
    boolean categoryVisible(String category){return showAll||nodes.values().stream().anyMatch(node->{
        String status=str(node,"status","");return category.equals(str(node,"category",""))&&!bool(node,"hidden",false)
            &&(status.startsWith("Открыто")||status.startsWith("Доступно")||status.startsWith("Уровень")||status.startsWith("Начальная ветвь")||status.startsWith("Выбрана"));
    });}
    String branch(){return branch;}
    void focusNextBranch(int width,int height){
        ensurePosition(width,height);
        var available=SECTORS.stream().filter(category->nodes.values().stream()
            .anyMatch(node->category.equals(str(node,"category",""))&&visible(node))).toList();
        if(available.isEmpty()){branch="Все";return;}
        branch=available.get(Math.floorMod(available.indexOf(branch)+1,available.size()));
        var destination=nodes.entrySet().stream()
            .filter(e->visible(e.getValue())&&branch.equals(str(e.getValue(),"category","")))
            .map(e->positions.get(e.getKey())).filter(Objects::nonNull)
            .min(Comparator.comparingInt(CityTreeLayout.Point::tier)).orElse(null);
        if(destination!=null){int canvasWidth=selected.isBlank()?width:panelX(width);
            panX=canvasWidth*.5-destination.x()*zoom;panY=height*.48-destination.y()*zoom;
        }
    }
    void reset(int width,int height){zoom=.83;panX=width*.43;panY=height*.53;positioned=true;detailScroll=0;branch="Все";}
    void fitAll(int width,int height){
        if(positions.isEmpty())return;
        double minX=Double.POSITIVE_INFINITY,maxX=Double.NEGATIVE_INFINITY,minY=Double.POSITIVE_INFINITY,maxY=Double.NEGATIVE_INFINITY;
        for(var p:positions.values()){minX=Math.min(minX,p.x());maxX=Math.max(maxX,p.x());minY=Math.min(minY,p.y());maxY=Math.max(maxY,p.y());}
        int canvasWidth=selected.isBlank()?width:panelX(width);
        zoom=Math.clamp(Math.min((canvasWidth-104)/Math.max(1,maxX-minX+86),(height-140)/Math.max(1,maxY-minY+86)),.12,1.0);
        panX=canvasWidth*.5-(minX+maxX)*.5*zoom;panY=height*.51-(minY+maxY)*.5*zoom;positioned=true;branch="Все";
    }
    boolean positioned(){return positioned;}
    void restore(float savedZoom,float xFraction,float yFraction,int width,int height){
        zoom=Math.clamp(savedZoom,showAll?.12:.38,2.25);panX=Math.clamp((double)xFraction*width,-3500,width+3500);panY=Math.clamp((double)yFraction*height,-3500,height+3500);positioned=true;
    }
    float savedZoom(){return (float)zoom;}
    float savedPanX(int width){return width>0?(float)(panX/width):.43f;}
    float savedPanY(int height){return height>0?(float)(panY/height):.53f;}
    void focusCurrent(int width,int height){
        ensurePosition(width,height);String target=selected;
        if(target.isBlank()||!positions.containsKey(target))target=nodes.entrySet().stream()
            .filter(e->visible(e.getValue()))
            .filter(e->{String status=str(e.getValue(),"status","");return status.startsWith("Доступно")||status.startsWith("Открыто")||status.startsWith("Начальная ветвь")||status.startsWith("Уровень");})
            .max(Comparator.comparingDouble(e->positions.get(e.getKey()).x())).map(Map.Entry::getKey).orElse("");
        if(target.isBlank())target=positions.keySet().stream().findFirst().orElse("");
        CityTreeLayout.Point point=positions.get(target);if(point!=null){filter="Все";branch="Все";panX=(selected.isBlank()?width*.5:Math.min(width*.43,width-190))-point.x()*zoom;panY=height*.48-point.y()*zoom;detailScroll=0;}
    }
    void ensurePosition(int width,int height){if(!positioned)reset(width,height);}
    void zoom(double factor,double x,double y,int width,int height){
        ensurePosition(width,height);double next=Math.clamp(zoom*factor,showAll?.12:.38,2.25);
        if(next==zoom)return;double worldX=(x-panX)/zoom,worldY=(y-panY)/zoom;zoom=next;panX=x-worldX*zoom;panY=y-worldY*zoom;
    }
    boolean panelAt(double x,int width){return !selected.isBlank()&&x>=panelX(width);}
    int panelX(int width){return width<560?Math.max(60,width/5):width-Math.min(342,Math.max(245,width/3));}
    boolean scroll(double x,double y,double steps,int width,int height){
        if(y<52)return false;
        if(panelAt(x,width)){detailScroll=Math.clamp(detailScroll+(steps<0?34:-34),0,2400);return true;}
        zoom(steps<0?1/1.16:1.16,x,y,width,height);return true;
    }
    void pan(double dx,double dy,int width,int height){ensurePosition(width,height);panX=Math.clamp(panX+dx,-3500,width+3500);panY=Math.clamp(panY+dy,-3500,height+3500);}
    void drag(boolean value){dragging=value;}
    boolean dragging(){return dragging;}
    String hit(double x,double y,int width,int height){
        if(y<52||y>height-27||panelAt(x,width))return "";
        ensurePosition(width,height);
        for(var entry:nodes.entrySet()){
            if(!visible(entry.getValue()))continue;var point=positions.get(entry.getKey());if(point==null)continue;
            double dx=x-(panX+point.x()*zoom),dy=y-(panY+point.y()*zoom),radius=Math.max(9,nodeRadius()+3);
            if(dx*dx+dy*dy<=radius*radius)return entry.getKey();
        }
        return "";
    }
    String action(String id){var node=nodes.get(id);return node==null?"":str(node,"action","");}
    private boolean visible(JsonObject node){return filter.equals("Все")||filter.equals("Здания")&&str(node,"kind","").equals("building")||filter.equals("Исследования")&&str(node,"kind","").equals("research")||filter.equals("Возможности")&&(str(node,"kind","").equals("content")||str(node,"kind","").equals("specialization"));}
    void render(GuiGraphicsExtractor g,Font font,JsonObject theme,JsonObject detail,int width,int height,int mouseX,int mouseY,int lineBrightness){
        ensurePosition(width,height);int bg=UiTheme.color(theme,"background"),panel=UiTheme.color(theme,"panel"),muted=UiTheme.color(theme,"muted"),text=UiTheme.color(theme,"text"),accent=UiTheme.color(theme,"accent");
        int canvasWidth=panelAt(width-1,width)?panelX(width):width;
        g.fill(0,0,width,height,bg);g.enableScissor(0,52,canvasWidth,height-27);
        int border=UiTheme.color(theme,"border");
        int pattern=CivicStyle.mix(bg,border,25);
        int step=Math.max(20,(int)Math.round(48*zoom));
        int startX=Math.floorMod((int)Math.round(panX),step),startY=Math.floorMod((int)Math.round(panY),step);
        for(int gx=startX;gx<canvasWidth;gx+=step)for(int gy=startY;gy<height-26;gy+=step)if(gy>=52)g.fill(gx,gy,gx+1,gy+1,pattern);
        for(int tier=1;tier<=largestRing;tier++){
            int radius=(int)Math.round(tier*230*zoom);
            if(radius<2400&&(zoom>=.5||tier==1||tier%2==0)
               &&ringVisible(panX,panY,radius,canvasWidth,height))
                orbit(g,panX,panY,radius,CivicStyle.mix(bg,border,tier==1?48:29),canvasWidth,height);
        }
        int brightness=switch(Math.clamp(lineBrightness,0,2)){case 0->25;case 1->49;default->76;};
        for(var link:links){
            JsonObject node=nodes.get(link.child()),source=nodes.get(link.parent());
            if(!visible(node)||!visible(source))continue;
            var start=positions.get(link.parent());var end=positions.get(link.child());
            double x1=panX+start.x()*zoom,y1=panY+start.y()*zoom,x2=panX+end.x()*zoom,y2=panY+end.y()*zoom;
            if(!segmentVisible(x1,y1,x2,y2,canvasWidth,height))continue;
            boolean active=str(node,"status","").startsWith("Открыто")||str(node,"status","").startsWith("Уровень")||str(node,"status","").startsWith("Доступно");
            boolean highlighted=selected.equals(link.child())||selected.equals(link.parent());
            int ink=link.choice()?CivicStyle.financeInk(theme,"warning"):branchInk(theme,str(node,"category",""));
            int strength=active?brightness+10:Math.max(16,brightness-17);
            if(link.parent().equals("building:town_hall")&&end.tier()>1&&!highlighted)
                strength=Math.min(strength,17);
            int color=CivicStyle.mix(bg,ink,Math.min(96,strength+(highlighted?30:0)));
            stroke(g,x1,y1,x2,y2,highlighted?2:1,color);
        }
        for(var e:nodes.entrySet()){
            JsonObject node=e.getValue();if(!visible(node))continue;var pos=positions.get(e.getKey());if(pos==null)continue;
            int x=(int)Math.round(panX+pos.x()*zoom),y=(int)Math.round(panY+pos.y()*zoom),radius=nodeRadius();
            if(x+radius<0||x-radius>canvasWidth||y+radius<52||y-radius>height-27)continue;
            boolean focused=selected.equals(e.getKey()),hovered=Math.abs(mouseX-x)<radius&&Math.abs(mouseY-y)<radius;
            boolean choice=str(node,"kind","").equals("specialization");
            boolean completed=str(node,"status","").startsWith("Открыто")||str(node,"status","").startsWith("Уровень")||str(node,"status","").startsWith("Выбрана");
            int color=bool(node,"unique",false)||choice?CivicStyle.financeInk(theme,"warning"):completed?CivicStyle.financeInk(theme,"positive"):branchInk(theme,str(node,"category",""));
            boolean locked=bool(node,"hidden",false)||str(node,"status","").startsWith("Нужно")||str(node,"choiceState","").equals("other");if(locked)color=CivicStyle.mix(bg,color,45);
            int halo=focused?CivicStyle.mix(bg,color,27):hovered?CivicStyle.mix(bg,color,18):CivicStyle.mix(bg,color,8);
            if(focused||hovered){if(choice)diamond(g,x,y,radius+11,halo);else disk(g,x,y,radius+11,halo);}
            if(choice){diamond(g,x,y,radius+3,color);diamond(g,x,y,radius+1,CivicStyle.mix(bg,color,45));diamond(g,x,y,Math.max(2,radius-2),panel);}
            else{disk(g,x,y,radius+3,color);disk(g,x,y,radius+1,CivicStyle.mix(bg,color,45));disk(g,x,y,Math.max(2,radius-2),panel);}
            if(completed){int mark=Math.max(2,radius-4);g.fill(x-mark,y+mark-1,x+mark,y+mark+1,color);}
        }
        // GuiGraphicsExtractor batches solid shapes and textured quads separately.
        // Keep every icon in a later stratum so another node's fill cannot cover it.
        g.nextStratum();
        for(var e:nodes.entrySet()){
            JsonObject node=e.getValue();if(!visible(node))continue;var pos=positions.get(e.getKey());if(pos==null)continue;
            int x=(int)Math.round(panX+pos.x()*zoom),y=(int)Math.round(panY+pos.y()*zoom),radius=nodeRadius();
            if(x+radius<0||x-radius>canvasWidth||y+radius<52||y-radius>height-27)continue;
            g.pose().pushMatrix();g.pose().translate(x,y);nodeIcon(g,node,Math.clamp(radius*2-4,10,24));g.pose().popMatrix();
        }
        g.nextStratum();
        for(var e:nodes.entrySet()){
            JsonObject node=e.getValue();if(!visible(node))continue;var pos=positions.get(e.getKey());if(pos==null)continue;
            int x=(int)Math.round(panX+pos.x()*zoom),y=(int)Math.round(panY+pos.y()*zoom),radius=nodeRadius();
            if(x+radius<0||x-radius>canvasWidth||y+radius<52||y-radius>height-27)continue;
            boolean focused=selected.equals(e.getKey()),hovered=Math.abs(mouseX-x)<radius&&Math.abs(mouseY-y)<radius;
            int color=branchInk(theme,str(node,"category",""));
            if(bool(node,"unique",false)&&!str(node,"choiceName","").isBlank()&&zoom>=.6)g.text(font,str(node,"choiceState","").equals("chosen")?"✓":"◇",x+radius-5,y-radius-7,color,false);
            if(zoom>=.78||focused||hovered){String label=CivicStyle.clip(str(node,"title",""),Math.max(75,(int)(132*zoom)));int labelX=Math.max(4,x-font.width(label)/2),labelY=y+radius+9;
                g.fill(labelX-4,labelY-3,labelX+font.width(label)+4,labelY+font.lineHeight+3,CivicStyle.mix(bg,panel,78));
                g.fill(labelX-4,labelY-3,labelX-2,labelY+font.lineHeight+3,color);
                g.text(font,label,labelX,labelY,focused?text:muted,false);
            }
        }
        g.disableScissor();
        if(width>=760&&detail==null){
            int lx=16,ly=66;String[] labels={"Доступно","Построено","Требует условий","Выбор направления"};
            int[] colors={accent,CivicStyle.financeInk(theme,"positive"),muted,CivicStyle.financeInk(theme,"warning")};
            int legendWidth=0;for(String label:labels)legendWidth+=font.width(label)+25;
            g.fill(10,60,Math.min(width,legendWidth+18),86,CivicStyle.mix(bg,panel,68));
            for(int i=0;i<labels.length;i++){g.fill(lx,ly+4,lx+7,ly+11,colors[i]);g.text(font,labels[i],lx+11,ly+3,text,false);lx+=font.width(labels[i])+25;}
        }
        if(detail!=null&&panelAt(width-1,width))drawDetail(g,font,theme,detail,width,height);
        String hovered=hit(mouseX,mouseY,width,height);
        if(!hovered.isBlank()){
            JsonObject node=nodes.get(hovered);
            int cardWidth=Math.min(248,canvasWidth-16),cardX=Math.clamp(mouseX+15,8,Math.max(8,canvasWidth-cardWidth-8));
            int cardY=mouseY+58<height-28?mouseY+14:mouseY-57;
            g.fill(cardX,cardY,cardX+cardWidth,cardY+48,panel);
            int color=branchInk(theme,str(node,"category",""));
            g.fill(cardX,cardY,cardX+3,cardY+48,color);
            g.text(font,CivicStyle.clip(str(node,"title",""),cardWidth-20),cardX+11,cardY+7,text,false);
            CivicStyle.detail(g,str(node,"status",""),cardX+11,cardY+25,cardWidth-20,muted);
        }
        g.fill(0,0,width,51,CivicStyle.mix(bg,panel,36));g.fill(0,51,width,52,CivicStyle.mix(bg,accent,30));
        if(width>=650)g.text(font,"Развитие города",104,19,text,false);
        g.fill(0,height-27,width,height,CivicStyle.mix(bg,panel,40));
        CivicStyle.detail(g,"Колёсико — масштаб · Перетащить — переместить · Нажать узел — условия",16,height-18,Math.max(80,width-76),muted);
        g.text(font,(int)Math.round(zoom*100)+"%",Math.max(16,width-47),height-19,accent,false);
    }
    private static int branchInk(JsonObject theme,String category){
        int index=SECTORS.indexOf(category);if(index<0)index=Math.floorMod(category.hashCode(),BRANCH_COLORS.length);
        return CivicStyle.mix(CivicStyle.inkAccent(theme),BRANCH_COLORS[index],55);
    }
    private int nodeRadius(){return zoom>=.2?Math.max(13,(int)Math.round(23*zoom)):Math.max(7,(int)Math.round(65*zoom));}
    private static void nodeIcon(GuiGraphicsExtractor g,JsonObject node,int size){
        String id=str(node,"id",""),kind=str(node,"kind",""),category=str(node,"category","");
        String icon=bool(node,"unique",false)||kind.equals("specialization")?"choice":
            kind.equals("research")?"research":id.contains("town_hall")?"hall":
            id.contains("market")||id.contains("guild")?"trade":
            id.contains("academy")||id.contains("library")?"science":
            switch(category){case "Управление"->"governance";case "Производство"->"production";
                case "Торговля"->"trade";case "Инфраструктура"->"infrastructure";
                case "Оборона"->"defense";case "Наука"->"science";
                case "Культура"->"culture";case "Энергия"->"energy";
                case "Исследования"->"research";default->"hall";};
        TreeIconRaster.draw(g,icon,size);
    }
    private static boolean segmentVisible(double x1,double y1,double x2,double y2,int width,int height){
        return Math.max(x1,x2)>=-3&&Math.min(x1,x2)<=width+3
            &&Math.max(y1,y2)>=49&&Math.min(y1,y2)<=height-24;
    }
    private static boolean ringVisible(double cx,double cy,int radius,int width,int height){
        double nearX=Math.clamp(cx,0,width),nearY=Math.clamp(cy,52,height-27);
        double closest=Math.hypot(cx-nearX,cy-nearY);
        double farthest=Math.max(Math.max(Math.hypot(cx,cy-52),Math.hypot(cx-width,cy-52)),
            Math.max(Math.hypot(cx,cy-height+27),Math.hypot(cx-width,cy-height+27)));
        return closest<=radius+2&&farthest>=radius-2;
    }
    private static void orbit(GuiGraphicsExtractor g,double cx,double cy,int radius,int color,int width,int height){
        int steps=Math.min(160,Math.max(24,(int)Math.ceil(2*Math.PI*radius/24)));
        double oldX=cx+radius,oldY=cy;
        for(int i=1;i<=steps;i++){
            double a=i*2*Math.PI/steps,x=cx+Math.cos(a)*radius,y=cy+Math.sin(a)*radius;
            if(segmentVisible(oldX,oldY,x,y,width,height))stroke(g,oldX,oldY,x,y,1,color);
            oldX=x;oldY=y;
        }
    }
    private static void stroke(GuiGraphicsExtractor g,double x1,double y1,double x2,double y2,int thickness,int color){
        double dx=x2-x1,dy=y2-y1,length=Math.hypot(dx,dy);if(length<.4)return;
        g.pose().pushMatrix();g.pose().translate((float)x1,(float)y1);g.pose().rotate((float)Math.atan2(dy,dx));
        g.fill(0,-thickness/2,(int)Math.ceil(length)+1,(thickness+1)/2,color);g.pose().popMatrix();
    }
    private static void disk(GuiGraphicsExtractor g,int cx,int cy,int radius,int color){
        // Group nearby rows into wide bands: the silhouette stays round but needs far fewer quads.
        int quantum=radius>=13?3:2,first=-radius,previous=-1;
        for(int dy=-radius;dy<=radius+1;dy++){
            int dx=dy<=radius?(int)Math.sqrt(Math.max(0,radius*radius-dy*dy)):-1;
            if(dx>=0)dx=Math.min(radius,((dx+quantum/2)/quantum)*quantum);
            if(previous>=0&&dx!=previous){g.fill(cx-previous,cy+first,cx+previous+1,cy+dy,color);first=dy;}
            previous=dx;
        }
    }
    private static void diamond(GuiGraphicsExtractor g,int cx,int cy,int radius,int color){
        for(int dy=-radius;dy<=radius;dy++){int dx=radius-Math.abs(dy);g.fill(cx-dx,cy+dy,cx+dx+1,cy+dy+1,color);}
    }
    private void drawDetail(GuiGraphicsExtractor g,Font font,JsonObject theme,JsonObject data,int width,int height){
        int x=panelX(width),w=width-x,panel=UiTheme.color(theme,"panel"),text=UiTheme.color(theme,"text"),muted=UiTheme.color(theme,"muted"),accent=UiTheme.color(theme,"accent");
        g.fill(x,52,width,height-27,panel);g.fill(x,52,x+2,height-27,CivicStyle.mix(panel,accent,70));
        g.enableScissor(x+8,61,width-8,height-64);
        int y=69-detailScroll,maxWidth=w-34;
        JsonObject node=nodes.get(str(data,"id",""));
        int branch=branchInk(theme,node==null?"Управление":str(node,"category","Управление"));
        String status=str(data,"status","");boolean done=status.startsWith("Уровень")||status.startsWith("Открыто")||status.startsWith("Выбрана");
        boolean blocked=status.startsWith("Требуются")||status.startsWith("Нужно");
        int statusInk=done?CivicStyle.financeInk(theme,"positive"):blocked?muted:accent;
        g.fill(x+13,y-6,width-13,y+15,CivicStyle.mix(panel,branch,13));
        g.fill(x+13,y-6,x+16,y+15,branch);
        g.text(font,str(data,"kind","").equals("research")?"ИССЛЕДОВАНИЕ":str(data,"kind","").equals("building")?"ПОСТРОЙКА":str(data,"kind","").equals("specialization")?"ВЫБОР НАПРАВЛЕНИЯ":"ВОЗМОЖНОСТЬ",x+23,y,branch,false);y+=30;
        for(String part:CivicStyle.wrap(str(data,"title",""),maxWidth)){g.text(font,part,x+17,y,text,false);y+=13;}y+=8;
        int badgeLines=CivicStyle.wrap(status,CivicStyle.detailWidth(maxWidth-18)).size();int badgeHeight=Math.max(26,badgeLines*11+12);
        g.fill(x+13,y-4,width-13,y+badgeHeight,CivicStyle.mix(panel,statusInk,15));g.fill(x+13,y-4,x+16,y+badgeHeight,statusInk);
        for(String line:CivicStyle.wrap(status,CivicStyle.detailWidth(maxWidth-18))){CivicStyle.detail(g,line,x+23,y+3,maxWidth-18,statusInk);y+=11;}y+=badgeHeight-badgeLines*11+11;
        if(data.has("description")){for(var part:data.getAsJsonArray("description")){String paragraph=part.getAsString();CivicStyle.detailBlock(g,paragraph,x+17,y,maxWidth,theme);y+=CivicStyle.detailBlockHeight(paragraph,maxWidth)+7;}y+=6;}
        if(data.has("specialization")){g.text(font,"СПЕЦИАЛИЗАЦИЯ",x+17,y,CivicStyle.financeInk(theme,"warning"),false);y+=17;for(String line:CivicStyle.wrap(str(data,"specialization",""),maxWidth)){g.text(font,line,x+17,y,text,false);y+=12;}y+=8;
            CivicStyle.detailBlock(g,str(data,"specializationDescription",""),x+17,y,maxWidth,theme);y+=CivicStyle.detailBlockHeight(str(data,"specializationDescription",""),maxWidth);
            if(data.has("uniqueMinimumLevel")){g.text(font,"Бонус здания — с уровня "+integer(data,"uniqueMinimumLevel",3),x+17,y+3,accent,false);y+=17;}y+=14;}
        if(data.has("requirements")&&data.getAsJsonArray("requirements").size()>0){g.text(font,"ЧТО НУЖНО ОТКРЫТЬ",x+17,y,accent,false);y+=19;for(var part:data.getAsJsonArray("requirements")){
                String requirement=part.getAsString();int progress=progress(requirement),tone=progress>=100?CivicStyle.financeInk(theme,"positive"):CivicStyle.financeInk(theme,"warning");
                int rows=CivicStyle.wrap(requirement,maxWidth-20).size();int h=Math.max(31,rows*12+11);
                g.fill(x+13,y-3,width-13,y+h,CivicStyle.mix(panel,tone,9));g.fill(x+13,y-3,x+16,y+h,tone);
                int lineY=y+3;for(String line:CivicStyle.wrap(requirement,maxWidth-20)){g.text(font,line,x+23,lineY,text,false);lineY+=12;}
                y+=h+6;
            }y+=7;}
        if(data.has("cost")){g.text(font,CivicStyle.clip(str(data,"costLabel","СТОИМОСТЬ"),maxWidth),x+17,y,accent,false);y+=19;
            for(String line:CivicStyle.wrap(str(data,"cost",""),maxWidth)){g.text(font,line,x+17,y,text,false);y+=12;}y+=14;}
        if(data.has("researchCost")){int seconds=integer(data.getAsJsonObject("researchCost"),"seconds",0);g.text(font,"Время: "+seconds/60+" мин",x+17,y,muted,false);y+=20;}
        if(data.has("materials")){JsonArray materials=data.getAsJsonArray("materials");g.text(font,"МАТЕРИАЛЫ",x+17,y,accent,false);y+=18;if(materials.size()==0){g.text(font,"Дополнительные ресурсы не требуются",x+17,y,muted,false);y+=14;}
            for(var entry:materials){var item=entry.getAsJsonObject();long required=item.get("required").getAsLong(),stored=item.has("stored")?item.get("stored").getAsLong():-1,missing=item.get("missing").getAsLong();
                int tone=missing==0?CivicStyle.financeInk(theme,"positive"):missing<0?muted:accent;
                var nameLines=CivicStyle.wrap(str(item,"name",""),maxWidth-20);
                g.fill(x+13,y-4,width-13,y+nameLines.size()*12+30,CivicStyle.mix(panel,tone,8));
                for(String line:nameLines){g.text(font,line,x+19,y,text,false);y+=12;}
                String amount=stored<0?"Нужно "+required+" · запас уточняется":"На складе "+stored+" / "+required+(missing>0?" · не хватает "+missing:"");
                CivicStyle.detail(g,amount,x+19,y+2,maxWidth-9,tone);y+=16;
                int barWidth=Math.max(4,maxWidth-12);g.fill(x+19,y,width-19,y+3,CivicStyle.mix(panel,muted,30));
                if(stored>=0&&required>0)g.fill(x+19,y,x+19+(int)(barWidth*Math.clamp((double)stored/required,0,1)),y+3,tone);
                y+=14;
            }
            if(data.has("moreMaterials")){g.text(font,"И ещё "+integer(data,"moreMaterials",0)+" типов в плане развития",x+17,y,muted,false);y+=14;}
        }
        else if(str(data,"kind","").equals("research")){g.text(font,"Материалы не требуются · нужны знания",x+17,y,muted,false);y+=14;}
        g.disableScissor();
        g.fill(x+12,height-68,width-12,height-67,CivicStyle.mix(panel,accent,38));
    }
    private static int progress(String requirement){
        int slash=requirement.lastIndexOf('/');if(slash<0)return -1;
        try{String before=requirement.substring(0,slash).stripTrailing();int i=before.length()-1;while(i>=0&&Character.isDigit(before.charAt(i)))i--;
            long have=Long.parseLong(before.substring(i+1)),need=Long.parseLong(requirement.substring(slash+1).strip());
            return need==0?100:(int)Math.clamp(have*100/need,0,100);
        }catch(NumberFormatException error){return -1;}
    }
}
