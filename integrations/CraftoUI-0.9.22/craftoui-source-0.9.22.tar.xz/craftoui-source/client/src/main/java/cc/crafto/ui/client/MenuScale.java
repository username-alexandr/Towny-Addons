package cc.crafto.ui.client;

/** Display and cycle menu scale in whole ten-percent steps. */
final class MenuScale {
    private MenuScale(){}
    static int percent(float value){
        return Float.isFinite(value)?Math.clamp(Math.round(value*10),7,13)*10:100;
    }
    static float normalized(float value){return percent(value)/100f;}
    static float next(float value){int percent=percent(value);return (percent>=130?70:percent+10)/100f;}
    static float previous(float value){int percent=percent(value);return (percent<=70?130:percent-10)/100f;}
}
