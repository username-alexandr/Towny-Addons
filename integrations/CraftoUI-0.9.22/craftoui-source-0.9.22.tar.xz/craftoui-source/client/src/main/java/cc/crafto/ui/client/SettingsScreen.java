package cc.crafto.ui.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Local preferences are staged on this screen until the player applies them. */
final class SettingsScreen extends PanelScreen {
    final MenuScreen parent;
    private final CraftoUIClient client;
    private final ClientSettings draft;
    private boolean returning,confirmExit;
    private int section;
    private int scrollBeforeConfirm;
    private long savedUntil;

    SettingsScreen(MenuScreen parent,CraftoUIClient client){
        super("Настройки CraftoUI",client);this.parent=parent;this.client=client;
        draft=client.settings.preview();parent.suspended=true;
    }
    void resume(){returning=false;changed();}
    ClientSettings draftSettings(){return draft;}
    private void update(){savedUntil=0;changed();}
    private void apply(){
        if(!draft.sameAppearance(client.settings)){
            client.settings.applyAppearance(draft);
            minecraft.options.menuBackgroundBlurriness().set(draft.blurRadius());
            minecraft.options.save();
            CivicStyle.configure(client.settings);
            client.settings.save();
            parent.reloadTheme();
        }
        savedUntil=System.nanoTime()+2_500_000_000L;
        changed();
    }
    @Override protected void init(){
        var s=draft;
        begin(UiTheme.resolve(client.lastTheme,s.themeMode(),s.highContrast),"Настройки интерфейса","Проверьте изменения на образце, затем примените их","settings");
        CivicStyle.configure(s);
        if(confirmExit){
            heading="Выйти из настроек?";
            subtitle="Изменения не сохранены";
            icon="warning";
            noTabs();
            info("Выйти без сохранения?","Если вернуться назад сейчас, изменения в меню не применятся. Чтобы сохранить их, останьтесь и нажмите «Применить».","warning",0);
            headerBack("← Остаться",this::cancelExit);
            fixed("Выйти без сохранения",left+span-172,layout.footerY(),172,false,this::leave);
            status="Ваши изменения пока видны только в примере";
            finish();CivicStyle.configure(client.settings);return;
        }
        tab("Оформление","theme",0,3,section==0,()->{section=0;resetScroll();changed();});
        tab("Дерево города","planner",1,3,section==1,()->{section=1;resetScroll();changed();});
        tab("Контракты","hud",2,3,section==2,()->{section=2;resetScroll();changed();});
        footer(this::onClose,"Применить",this::apply);
        int cols=columns(255,2),w=cellWidth(cols);
        if(section==0){
            int previewWidth=Math.min(span-8,Math.round(Math.min(320,span-8)*s.scale));
            int previewHeight=Math.max(48,Math.round((s.density==1?46:56)*s.scale));
            card("Пример кнопки","Так будут выглядеть подписи в меню","settings","setting",false,0,0,previewWidth,previewHeight,null).active=false;
            int y=previewHeight+14;
            setting("Цветовая тема","Тёмное или светлое оформление","theme",s.themeMode().equals("light")?"Светлая":"Тёмная",0,cols,w,y,()->{s.themeMode=s.themeMode().equals("dark")?"light":"dark";update();});
            setting("Контраст текста","Более чёткие подписи и границы","theme",s.highContrast?"Высокий":"Обычный",1,cols,w,y,()->{s.highContrast=!s.highContrast;update();});
            setting("Размер описаний","Увеличить подписи во всех карточках","scale",s.textSize==1?"Крупный":"Обычный",2,cols,w,y,()->{s.textSize=1-s.textSize;update();});
            setting("Плотность меню","Компактные ряды в главных разделах","scale",s.density==1?"Компактно":"Удобно",3,cols,w,y,()->{s.density=1-s.density;update();});
            setting("Масштаб меню","Размер основных меню и окон аддонов","scale",MenuScale.percent(s.scale)+"%",4,cols,w,y,()->{s.scale=MenuScale.next(s.scale);update();});
            setting("Затемнение мира","От выключенного до сильного","theme",new String[]{"Выкл.","Слабое","Среднее","Сильное"}[s.shadeLevel],5,cols,w,y,()->{s.shadeLevel=(s.shadeLevel+1)%4;update();});
            setting("Размытие фона","Размытие меню после применения","blur",new String[]{"Выкл.","Слабое","Среднее","Сильное"}[s.blurLevel()],6,cols,w,y,()->{s.blurLevel=(s.blurLevel()+1)%4;s.blur=s.blurLevel>0;update();});
            setting("Анимации","Плавное появление главного меню","animation",s.animations?"Вкл.":"Выкл.",7,cols,w,y,()->{s.animations=!s.animations;update();});
            int end=y+((8+cols-1)/cols)*64+10;
            card("Вернуть оформление по умолчанию","Сбросить тему, текст, плотность, масштаб и фон","settings","setting",false,0,end,Math.min(span-8,450),58,()->{
                s.themeMode="dark";s.highContrast=false;s.textSize=0;s.density=0;s.scale=1;s.shadeLevel=2;s.blurLevel=0;s.blur=false;s.animations=true;
                update();
            });
        }else if(section==1){
            int y=info("Дерево развития","Положение и масштаб дерева можно сохранить. Кнопка «Мой путь» переведёт к текущей или ближайшей доступной ветке.","planner",0);
            setting("Запоминать положение","Сохранить масштаб и сдвиг между открытиями","planner",s.treeRemember?"Вкл.":"Выкл.",0,cols,w,y,()->{s.treeRemember=!s.treeRemember;update();});
            setting("Яркость связей","Выделить ветви и варианты специализации","planner",new String[]{"Тихие","Обычные","Яркие"}[s.treeLines],1,cols,w,y,()->{s.treeLines=(s.treeLines+1)%3;update();});
            info("Как пользоваться","Колёсико приближает дерево, перетаскивание перемещает его. Выбор узла открывает справа требования и стоимость.","planner",y+76);
        }else{
            int y=info("Панель во время игры","Включите панель, затем выберите задания, порядок, размер и место на экране.","hud",0);
            setting("Показывать панель","Закреплённые задания поверх игрового мира","hud",s.contractsHud?"Вкл.":"Выкл.",0,cols,w,y,()->{s.contractsHud=!s.contractsHud;update();});
            setting("Выбрать и расположить","Настройка заданий и положения панели","settings","Открыть",1,cols,w,y,()->{returning=true;minecraft.gui.setScreen(new PersonalScreen(this,client));});
            info("Что можно изменить","Отметьте нужные контракты, измените порядок и размер стрелками, затем перетащите панель. Размер панели сохраняется отдельно.","orders",y+(2+cols-1)/cols*64+10);
        }
        status=System.nanoTime()<savedUntil?"Сохранено":s.sameAppearance(client.settings)?"Изменения появятся здесь до применения":"Назад / Esc — изменения не сохранятся";
        finish();CivicStyle.configure(client.settings);
    }
    private void setting(String title,String detail,String icon,String badge,int index,int cols,int w,int start,Runnable action){
        card(title,detail,icon,"setting",false,index%cols*(w+10),start+index/cols*64,w,58,action).badge(badge);
    }
    @Override public void extractBackground(GuiGraphicsExtractor g,int x,int y,float delta){
        synchronizeWidgets();
        if(draft.blurLevel()>0)extractBlurredBackground(g);
        g.fill(0,0,width,height,UiTheme.shade(theme,draft.shadeLevel));
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g,int x,int y,float delta){
        synchronizeWidgets();
        CivicStyle.configure(draft);
        try{super.extractRenderState(g,x,y,delta);}finally{CivicStyle.configure(client.settings);}
    }
    @Override public void tick(){
        if(savedUntil!=0&&System.nanoTime()>=savedUntil){savedUntil=0;changed();}
        synchronizeWidgets();
    }
    private void cancelExit(){confirmExit=false;scroll=scrollBeforeConfirm;changed();}
    private void leave(){returning=true;parent.suspended=false;minecraft.gui.setScreen(parent);}
    @Override public void onClose(){
        if(confirmExit){cancelExit();return;}
        if(!draft.sameAppearance(client.settings)){scrollBeforeConfirm=scroll;confirmExit=true;resetScroll();changed();return;}
        leave();
    }
    @Override public void removed(){if(!returning)parent.releaseSession();}
}
