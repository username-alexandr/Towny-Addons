#!/usr/bin/env python3
"""Package the compiled Fabric client against the last compatible release resources.

Keep the original Fabric metadata and nested dependencies, and replace every class
with the checked production compilation before adding newly generated classes.
"""
from pathlib import Path
import re
import zipfile

root = Path(__file__).resolve().parents[1]
properties = (root / 'gradle.properties').read_text()
server = re.search(r'(?m)^version=(.+)$', properties).group(1)
client = re.search(r'(?m)^client_version=(.+)$', properties).group(1)
source = root / 'tools/build-baseline' / 'CraftoUI-Fabric-26.2-0.9.20.jar'
if not source.is_file():
    source = root / 'jars' / 'CraftoUI-Fabric-26.2-0.9.20.jar'
target = root / 'jars' / f'CraftoUI-Fabric-26.2-{client}.jar'
classes = root / 'build/direct/classes'
if not source.is_file():
    raise SystemExit(f'Missing compatible previous Fabric JAR: {source}')

with zipfile.ZipFile(source) as previous, zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as release:
    seen = set(previous.namelist())
    for entry in previous.infolist():
        data = previous.read(entry.filename)
        if entry.filename.endswith('.class'):
            compiled = classes / entry.filename
            if not compiled.is_file():
                continue  # Removed source class; do not retain a stale inner class.
            data = compiled.read_bytes()
        elif entry.filename == 'fabric.mod.json':
            data = re.sub(rb'("version"\s*:\s*")[^"]+("\s*,)',lambda m:m.group(1)+client.encode()+m.group(2),data,count=1)
        release.writestr(entry, data)
    for compiled in sorted((classes / 'cc/crafto/ui/client').rglob('*.class')):
        name = compiled.relative_to(classes).as_posix()
        if name not in seen:
            release.write(compiled, name)
    for resource in sorted((root / 'client/src/main/resources').rglob('*')):
        if resource.is_file():
            name = resource.relative_to(root / 'client/src/main/resources').as_posix()
            if name not in seen and name != 'fabric.mod.json':
                release.write(resource, name)

with zipfile.ZipFile(target) as archive:
    assert client.encode() in archive.read('fabric.mod.json')
    assert len(archive.namelist()) == len(set(archive.namelist()))
    print(target, 'classes:', sum(name.endswith('.class') for name in archive.namelist()))
