package cc.crafto.ui.client;

import cc.crafto.ui.Protocol;
import cc.crafto.ui.CityTreeLayout;
import com.google.gson.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import javax.imageio.ImageIO;
import java.util.*;

/** Synthetic city graph for visual review; no Minecraft or addon runtime required. */
public final class TreeVisualProbe {
    public static void main(String[] args)throws Exception {
        Path output=Path.of(args[0]),themes=Path.of(args[1]);
        JsonArray nodes=new JsonArray();
        nodes.add(Protocol.object("id","building:town_hall","title","Ратуша","category","Управление","kind","building","status","Открыто · уровень 2","parents",List.of()));
        String[] categories={"Управление","Производство","Торговля","Инфраструктура","Оборона","Наука","Культура","Энергия","Исследования"};
        String[] names={"Совет","Кузница","Рынок","Мосты","Казармы","Лаборатория","Театр","Электростанция","Архив"};
        String[] next={"Министерства","Плавильня","Гильдия купцов","Вокзал","Арсенал","Академия","Музей","Сеть энергии","Новая технология"};
        for(int i=0;i<categories.length;i++){
            String first="building:branch"+i;
            nodes.add(Protocol.object("id",first,"title",names[i],"category",categories[i],"kind",i==8?"research":"building","hidden",i==7,"status",i==7?"Закрыто · сначала откройте зависимости":i<3?"Открыто · уровень 1":"Доступно","parents",List.of("building:town_hall")));
            nodes.add(Protocol.object("id","building:leaf"+i,"title",next[i],"category",categories[i],"kind",i==8?"research":"building","hidden",i==7,"status",i<2?"Доступно":"Нужно открыть предыдущие узлы","parents",List.of(first)));
        }
        nodes.add(Protocol.object("id","specialization:choice","title","Путь города","category","Управление","kind","specialization","status","Выберите направление развития","parents",List.of("building:town_hall")));
        nodes.add(Protocol.object("id","building:unique","title","Уникальный завод","category","Производство","kind","building","unique",true,"status","Нужно выбрать специализацию","choiceName","Промышленный город","choiceState","other","parents",List.of("building:branch1","specialization:choice")));
        JsonObject detail=Protocol.object("id","building:branch1","title","Кузница","kind","building","status","Уровень 1 / 5","description",List.of("Перерабатывает руду и открывает следующие производственные здания."),"requirements",List.of("Здание Ратуша · 2 / 2","Исследование Плавка · 1 / 2"),"cost","2 500 монет");
        detail.add("materials",Protocol.JSON.toJsonTree(List.of(Protocol.object("name","Железный слиток","required",160,"stored",112,"missing",48),Protocol.object("name","Камень","required",90,"stored",90,"missing",0))).getAsJsonArray());
        var visibility=new CityTreeCanvas();visibility.update(nodes,"");
        if(TreeIconRaster.count()!=11)throw new AssertionError("Bundled building art was not baked into solid GUI shapes");
        BufferedImage iconImage=new BufferedImage(24,24,BufferedImage.TYPE_INT_ARGB);
        Graphics2D iconGraphics=iconImage.createGraphics();var iconRender=new GuiGraphicsExtractor(iconGraphics);
        iconRender.pose().translate(12,12);TreeIconRaster.draw(iconRender,"hall",24);iconGraphics.dispose();
        long painted=0;Set<Integer> iconColors=new HashSet<>();
        for(int y=0;y<24;y++)for(int x=0;x<24;x++){int pixel=iconImage.getRGB(x,y);if((pixel>>>24)!=0){painted++;iconColors.add(pixel);}}
        if(painted<250||iconColors.size()<3)throw new AssertionError("Town hall icon disappeared from the visible fill layer");
        if(visibility.categoryVisible("Энергия"))throw new AssertionError("Locked category title leaked");
        if(!visibility.categoryVisible("Наука"))throw new AssertionError("Unlocked category missing");
        visibility.update(nodes,"",true);
        if(!visibility.categoryVisible("Энергия"))throw new AssertionError("Full tree omitted locked category");
        JsonArray full=new JsonArray();
        var layoutNodes=new ArrayList<CityTreeLayout.Node>();
        full.add(nodes.get(0));layoutNodes.add(new CityTreeLayout.Node("building:town_hall","Управление",List.of()));
        for(int i=0;i<108;i++){
            String id="building:catalog"+i,category=categories[i%categories.length];
            List<String> parents=i>=90?List.of("building:catalog"+(i-90)):List.of("building:town_hall");
            full.add(Protocol.object("id",id,"title","Здание "+i,"category",category,"kind","building","status",i<8?"Доступно":"Нужно открыть предыдущие узлы","parents",parents));
            layoutNodes.add(new CityTreeLayout.Node(id,category,parents));
        }
        var arranged=CityTreeLayout.arrange(layoutNodes);
        if(Math.hypot(arranged.get("building:town_hall").x(),arranged.get("building:town_hall").y())>0.001)throw new AssertionError("Town hall left centre");
        for(var node:layoutNodes)for(String parent:node.parents())if(arranged.get(node.id()).tier()<=arranged.get(parent).tier())throw new AssertionError("Prerequisite placed after child");
        var points=new ArrayList<>(arranged.values());
        for(int i=0;i<points.size();i++)for(int j=i+1;j<points.size();j++)
            if(Math.hypot(points.get(i).x()-points.get(j).x(),points.get(i).y()-points.get(j).y())<160)
                throw new AssertionError("Full-catalogue nodes overlap");
        for(var point:points)if(point.tier()>0&&Math.abs(Math.hypot(point.x(),point.y())-point.tier()*230)>.001)
            throw new AssertionError("Building escaped its stage ring");
        var overview=new CityTreeCanvas();overview.update(full,"",true);overview.fitAll(1280,720);
        JsonObject darkTheme=JsonParser.parseString(Files.readString(themes.resolve("dark.json"))).getAsJsonObject();
        BufferedImage overviewImage=new BufferedImage(2560,1440,BufferedImage.TYPE_INT_ARGB);
        Graphics2D overviewGraphics=overviewImage.createGraphics();overviewGraphics.scale(2,2);
        overview.render(new GuiGraphicsExtractor(overviewGraphics),Minecraft.getInstance().font,darkTheme,null,1280,720,-1,-1,1);
        overviewGraphics.dispose();ImageIO.write(overviewImage,"PNG",output.resolve("tree-full-catalogue-1280x720.png").toFile());
        for(String themeName:List.of("dark","classic")){
            JsonObject theme=JsonParser.parseString(Files.readString(themes.resolve(themeName+".json"))).getAsJsonObject();
            for(int[] size:new int[][]{{1280,720},{700,440}}){
                int width=size[0],height=size[1];var tree=new CityTreeCanvas();tree.update(nodes,"building:branch1");tree.reset(width,height);
                if(width<800)tree.zoom(.8,width/2d,height/2d,width,height);
                BufferedImage image=new BufferedImage(width*2,height*2,BufferedImage.TYPE_INT_ARGB);Graphics2D graphics=image.createGraphics();graphics.scale(2,2);
                graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
                tree.render(new GuiGraphicsExtractor(graphics),Minecraft.getInstance().font,theme,detail,width,height,-1,-1,1);
                graphics.dispose();ImageIO.write(image,"PNG",output.resolve("tree-"+themeName+"-"+width+"x"+height+".png").toFile());
                if(width==1280&&themeName.equals("dark")){
                    BufferedImage hover=new BufferedImage(width*2,height*2,BufferedImage.TYPE_INT_ARGB);Graphics2D hoverGraphics=hover.createGraphics();hoverGraphics.scale(2,2);
                    tree.render(new GuiGraphicsExtractor(hoverGraphics),Minecraft.getInstance().font,theme,detail,width,height,(int)(width*.43),(int)(height*.53),1);
                    hoverGraphics.dispose();ImageIO.write(hover,"PNG",output.resolve("tree-dark-hover-1280x720.png").toFile());
                }
            }
        }
        System.out.println("PASS city tree renders four theme and viewport previews plus 109-node concentric overview");
    }
}
