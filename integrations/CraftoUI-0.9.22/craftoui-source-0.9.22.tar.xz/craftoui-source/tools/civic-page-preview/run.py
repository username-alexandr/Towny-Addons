#!/usr/bin/env python3
"""Render the production CivicScreen and its real civic widgets using explicit AWT/UI doubles.
Reuses the checked-in bitmap-font adapter; does not launch Minecraft or a network server.
"""
from pathlib import Path
import argparse,ast,subprocess,os
p=argparse.ArgumentParser();p.add_argument('--java-home',type=Path,required=True);p.add_argument('--minecraft',type=Path,required=True);p.add_argument('--gson',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2];out=a.output.resolve();out.mkdir(parents=True,exist_ok=True);src=out/'adapter';classes=out/'classes';classes.mkdir(exist_ok=True)
def dictionary(path):
    tree=ast.parse(path.read_text())
    return next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='sources' for t in n.targets))
sources=dictionary(root/'tools/city-lifecycle-test/run.py')
visual=dictionary(root/'tools/city-preview/run.py')
for key in ('net/minecraft/client/gui/Font.java','net/minecraft/client/gui/GuiGraphicsExtractor.java'):
    sources[key]=visual[key]
sources['net/minecraft/client/gui/GuiGraphicsExtractor.java']=sources['net/minecraft/client/gui/GuiGraphicsExtractor.java'].replace('public final Graphics2D g;', 'public final java.util.List<String> texts=new ArrayList<>();public final Graphics2D g;public GuiGraphicsExtractor(){this(new java.awt.image.BufferedImage(1920,1080,2).createGraphics());}').replace('f.draw(g,s,x,y,c);','texts.add(s);f.draw(g,s,x,y,c);').replace(' final Pose pose=', ' public void setTooltipForNextFrame(Font f,java.util.List<FormattedCharSequence> lines,int x,int y){}\n final Pose pose=')
sources['net/minecraft/client/gui/GuiGraphicsExtractor.java']=sources['net/minecraft/client/gui/GuiGraphicsExtractor.java'].replace('public void scale(float x,float y){g.scale(x,y);}', 'public void scale(float x,float y){g.scale(x,y);}public void rotate(float a){g.rotate(a);}')
sources['net/minecraft/client/gui/GuiGraphicsExtractor.java']=sources['net/minecraft/client/gui/GuiGraphicsExtractor.java'].replace(' final Pose pose=', ' public void blit(net.minecraft.resources.Identifier id,int x,int y,int w,int h,float u0,float v0,float u1,float v1){try{var name=id.path().replace("textures/gui/tree/","");var file=java.nio.file.Path.of(System.getProperty("craftoui.icons"),name);var img=javax.imageio.ImageIO.read(file.toFile());g.drawImage(img,x,y,w,h,null);}catch(Exception ex){throw new RuntimeException(ex);}}\n final Pose pose=')
sources['net/minecraft/resources/Identifier.java']='package net.minecraft.resources;public record Identifier(String path){public static Identifier parse(String value){return new Identifier(value.split(":",2)[1]);}}'
sources.update({
'cc/crafto/ui/client/ClientSettings.java':'''package cc.crafto.ui.client;class ClientSettings{int textSize;}''',
'net/minecraft/client/Minecraft.java':'''package net.minecraft.client;import net.minecraft.client.gui.screens.Screen;public class Minecraft{private static final Minecraft INSTANCE=new Minecraft();public static Minecraft getInstance(){return INSTANCE;}public final net.minecraft.client.gui.Font font=new net.minecraft.client.gui.Font();public final Gui gui=new Gui();public final Options options=new Options();public static class Options{public Option menuBackgroundBlurriness(){return new Option();}public void save(){}}public static class Option{public void set(int v){}}public static class Gui{public Screen screen;public void setScreen(Screen s){screen=s;}}}''',
'net/minecraft/client/gui/components/Button.java':'''package net.minecraft.client.gui.components;
import net.minecraft.network.chat.Component;import net.minecraft.client.gui.GuiGraphicsExtractor;import net.minecraft.client.gui.components.events.GuiEventListener;import java.util.function.Consumer;
public class Button extends AbstractWidget implements GuiEventListener{protected static final Object DEFAULT_NARRATION=new Object();protected float alpha=1;public boolean active=true,hovered,focused;public int x,y,w,h;public final String label;public final Runnable press;private final Component message;public Tooltip tooltip;
 public Button(String label,int x,int y,int w,int h,Runnable action){this(x,y,w,h,Component.literal(label),b->action.run(),DEFAULT_NARRATION);}
 public Button(int x,int y,int w,int h,Component m,Consumer<Button> action,Object n){this.x=x;this.y=y;this.w=w;this.h=h;message=m;label=m.getString();press=()->action.accept(this);}
 public void setTooltip(Tooltip t){tooltip=t;}public void setAlpha(float a){alpha=a;}public int getX(){return x;}public int getY(){return y;}public int getWidth(){return w;}public int getHeight(){return h;}public void setY(int v){y=v;}public void setMessage(Component c){}public Component getMessage(){return message;}public boolean isHoveredOrFocused(){return hovered||focused;}public boolean isMouseOver(double mx,double my){return mx>=x&&mx<x+w&&my>=y&&my<y+h;}
 protected void extractContents(GuiGraphicsExtractor g,int mx,int my,float d){}public void render(GuiGraphicsExtractor g,int mx,int my,float d){hovered=isMouseOver(mx,my);extractContents(g,mx,my,d);}
}''',
'cc/crafto/ui/client/UiTheme.java':'''package cc.crafto.ui.client;import com.google.gson.JsonObject;final class UiTheme{static JsonObject resolve(JsonObject t,boolean dark){return t;}static JsonObject resolve(JsonObject t,String mode,boolean contrast){return t;}static int shade(JsonObject t,int level){return 0x80000000;}static int color(JsonObject t,String k){return t.has(k)?(int)Long.parseLong(t.get(k).getAsString().substring(1),16):0xFF343B4A;}}'''
})
key='net/minecraft/client/gui/screens/Screen.java'
sources[key]=sources[key].replace('protected final Font font=new Font();','protected final Font font=Minecraft.getInstance().font;').replace('public void setFocused(GuiEventListener b){}','public void setFocused(GuiEventListener b){for(var widget:widgets)widget.focused=widget==b;}').replace('public void extractRenderState(GuiGraphicsExtractor g,int x,int y,float d){}','public void extractRenderState(GuiGraphicsExtractor g,int x,int y,float d){for(var b:widgets)b.render(g,x,y,d);}').replace('e.x()>=b.x&&e.x()<b.x+b.w&&e.y()>=b.y&&e.y()<b.y+b.h','b.isMouseOver(e.x(),e.y())')
sources[key]=sources[key].replace('public void onClose(){}','public boolean mouseDragged(MouseButtonEvent e,double dx,double dy){return false;}public boolean mouseReleased(MouseButtonEvent e){return false;}public void onClose(){}')
sources[key]=sources[key].replace('public void setFocused(GuiEventListener b){','public GuiEventListener getFocused(){return null;}public void setFocused(GuiEventListener b){')
sources['net/minecraft/client/gui/components/EditBox.java']='''package net.minecraft.client.gui.components;import net.minecraft.client.gui.Font;import net.minecraft.network.chat.Component;import java.util.function.Consumer;
public class EditBox extends Button{private String value="";private Consumer<String> responder=x->{};public EditBox(Font f,int x,int y,int w,int h,Component label){super(label.getString(),x,y,w,h,()->{});}public void setMaxLength(int n){}public void setHint(Component hint){}public void setValue(String text){value=text;responder.accept(text);}public void setResponder(Consumer<String> action){responder=action;}}'''
sources['net/minecraft/client/input/MouseButtonEvent.java']='package net.minecraft.client.input;public record MouseButtonEvent(double x,double y,int button){public MouseButtonEvent(double x,double y){this(x,y,0);}}'
for name in ('FlatButton','CityCardButton','CivicCardButton','CivicStyle'):
    sources.pop('cc/crafto/ui/client/'+name+'.java',None)
sources['cc/crafto/ui/client/CivicPageProbe.java']=(Path(__file__).parent/'CivicPageProbe.java').read_text()
sources['cc/crafto/ui/client/TreeCameraProbe.java']=(Path(__file__).parent/'TreeCameraProbe.java').read_text()
sources['cc/crafto/ui/client/TreeVisualProbe.java']=(Path(__file__).parent/'TreeVisualProbe.java').read_text()
sources['cc/crafto/ui/client/CraftoUIClient.java']=sources['cc/crafto/ui/client/CraftoUIClient.java'].replace('class Settings{','class Settings extends ClientSettings{').replace('int textSize,shadeLevel=2,treeLines=1;','int shadeLevel=2,treeLines=1;')
for name,code in sources.items():f=src/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(code)
production=[root/'common/src/main/java/cc/crafto/ui'/n for n in ('Protocol.java','CityDashboardLayout.java','OrderGridLayout.java','TownUi.java','CivicPageLayout.java','CityTreeLayout.java')]+[root/'client/src/main/java/cc/crafto/ui/client'/n for n in ('CivicScreen.java','CityTreeCanvas.java','TreeIconRaster.java','CityCardButton.java','FlatButton.java','CivicCardButton.java','CivicStyle.java')]
subprocess.run([str(a.java_home/'bin/javac'),'--release','25','-encoding','UTF-8','-cp',str(a.gson),'-d',str(classes),*map(str,src.rglob('*.java')),*map(str,production)],check=True)
cmd=[str(a.java_home/'bin/java'),'-Djava.awt.headless=true','-Dminecraft.jar='+str(a.minecraft),'-Dcraftoui.icons='+str(root/'client/src/main/resources/assets/craftoui/textures/gui/tree'),'-cp',os.pathsep.join((str(classes),str(a.gson)))]
subprocess.run(cmd+['cc.crafto.ui.client.CivicLifecycleProbe'],check=True)
subprocess.run(cmd+['cc.crafto.ui.client.TreeCameraProbe'],check=True)
subprocess.run(cmd+['cc.crafto.ui.client.TreeVisualProbe',str(out),str(root/'server/src/main/resources/themes')],check=True)
subprocess.run(cmd+['cc.crafto.ui.client.CivicPageProbe',str(out),str(root/'server/src/main/resources/themes')],check=True)
