package cc.crafto.ui.client;
import cc.crafto.ui.Protocol;
import com.google.gson.*;
import java.util.*;
public final class TreeCameraProbe {
 private static void check(boolean test,String message){if(!test)throw new AssertionError(message);}
 public static void main(String[] args){
  JsonArray nodes=Protocol.JSON.toJsonTree(List.of(
   Protocol.object("id","root","title","Ратуша","category","Управление","kind","building","status","Уровень 1","parents",List.of()),
   Protocol.object("id","next","title","Кузница","category","Управление","kind","building","status","Доступно","parents",List.of("root")))).getAsJsonArray();
  var view=new CityTreeCanvas();view.update(nodes,"");view.reset(900,500);view.zoom(1.2,350,260,900,500);view.pan(-130,40,900,500);
  var restored=new CityTreeCanvas();restored.update(nodes,"");restored.restore(view.savedZoom(),view.savedPanX(900),view.savedPanY(500),900,500);
  check(Math.abs(restored.savedZoom()-view.savedZoom())<.0001,"zoom survives reopening");
  check(Math.abs(restored.savedPanX(900)-view.savedPanX(900))<.0001,"horizontal camera survives reopening");
  check(Math.abs(restored.savedPanY(500)-view.savedPanY(500))<.0001,"vertical camera survives reopening");
  restored.filter("Исследования");restored.focusCurrent(900,500);
  check(restored.filter().equals("Все"),"current path returns to visible branches");
  check(restored.savedZoom()>=.38&&restored.savedZoom()<=2.25,"current path retains safe zoom");
  restored.focusNextBranch(900,500);
  check(restored.branch().equals("Управление"),"branch shortcut focuses an available category");
  System.out.println("PASS saved tree camera and current path focus");
 }
}
