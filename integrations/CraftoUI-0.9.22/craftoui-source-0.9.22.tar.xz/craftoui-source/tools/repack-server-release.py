#!/usr/bin/env python3
"""Package Java 25-compiled common/API/server classes after a successful test run."""
from pathlib import Path
import re, zipfile
root=Path(__file__).resolve().parents[1]
version=re.search(r'(?m)^version=(.+)$',(root/'gradle.properties').read_text()).group(1)
classes=root/'build/direct/classes'
tests=root/'build/direct/tests.txt'
if not re.search(r'\b3[5-9]\d tests successful\b',tests.read_text()) or '0 tests failed' not in tests.read_text():
    raise SystemExit('The full JUnit suite must pass before packaging')
shared={p.relative_to(classes).as_posix():p.read_bytes() for p in (classes/'cc/crafto/ui').glob('*.class')}
server={p.relative_to(classes).as_posix():p.read_bytes() for p in (classes/'cc/crafto/ui/server').rglob('*.class')}
resources={}
for part in ('common','api','server'):
    base=root/part/'src/main/resources'
    if base.exists():
        for path in base.rglob('*'):
            if path.is_file():
                name=path.relative_to(base).as_posix()
                data=path.read_bytes()
                if name=='plugin.yml':data=data.replace(b'${version}',version.encode())
                resources[name]=data

def publish(name,entries):
    target=root/'jars'/name
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as jar:
        for path,data in sorted(entries.items()):
            info=zipfile.ZipInfo(path,(1980,2,1,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            jar.writestr(info,data)
    with zipfile.ZipFile(target) as jar:
        assert len(jar.namelist())==len(set(jar.namelist()))
    print(target)
publish(f'CraftoUI-API-{version}.jar',shared)
publish(f'CraftoUI-Folia-26.2-{version}.jar',shared|server|resources)
