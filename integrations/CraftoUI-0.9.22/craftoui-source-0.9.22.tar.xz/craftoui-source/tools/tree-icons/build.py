#!/usr/bin/env python3
"""Build original 24px city-tree emblems. No Minecraft or third-party textures used."""
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[2] / 'client/src/main/resources/assets/craftoui/textures/gui/tree'
ROOT.mkdir(parents=True, exist_ok=True)
INK = '#151e26'
PAPER = '#f7edda'

def icon(name, accent, draw):
    image = Image.new('RGBA', (24, 24), (0, 0, 0, 0))
    pen = ImageDraw.Draw(image)
    draw(pen, accent)
    image.save(ROOT / f'{name}.png')

def hall(p, c):
    p.polygon([(2,9),(12,2),(22,9)], fill=INK)
    p.polygon([(5,8),(12,4),(19,8)], fill=c)
    p.rectangle((4,9,20,21),fill=INK)
    p.rectangle((6,11,18,19),fill=PAPER)
    for x in (8,15):p.rectangle((x,11,x+1,19),fill=c)
    p.rectangle((11,14,13,21),fill=INK)
    p.rectangle((2,21,22,22),fill=c)

def governance(p,c):
    p.polygon([(3,6),(6,16),(18,16),(21,6),(16,10),(12,4),(8,10)],fill=INK)
    p.polygon([(5,8),(8,12),(12,6),(16,12),(19,8),(17,15),(7,15)],fill=c)
    p.rectangle((6,17,18,19),fill=INK);p.rectangle((7,18,17,18),fill=PAPER)
    p.rectangle((11,11,12,13),fill=PAPER)

def production(p,c):
    p.rectangle((3,10,20,20),fill=INK);p.polygon([(4,12),(9,8),(13,11),(18,8),(20,12)],fill=c)
    p.rectangle((16,3,20,10),fill=INK);p.rectangle((17,4,18,8),fill=PAPER)
    for x in (6,11,16):p.rectangle((x,14,x+2,16),fill=PAPER)
    p.rectangle((2,20,22,22),fill=c)

def trade(p,c):
    p.ellipse((8,2,16,10),fill=INK);p.ellipse((10,4,14,8),fill=c)
    p.rectangle((11,9,13,19),fill=INK);p.rectangle((4,10,20,12),fill=c)
    p.line((6,12,4,17,9,17,7,12),fill=INK,width=2)
    p.line((17,12,15,17,20,17,18,12),fill=INK,width=2)
    p.rectangle((8,19,16,21),fill=c)

def infrastructure(p,c):
    p.rectangle((2,9,22,13),fill=c);p.rectangle((2,13,22,21),fill=INK)
    p.ellipse((5,14,11,23),fill=PAPER);p.ellipse((13,14,19,23),fill=PAPER)
    p.rectangle((3,5,5,10),fill=INK);p.rectangle((19,5,21,10),fill=INK)
    p.rectangle((2,21,22,22),fill=c)

def defense(p,c):
    p.polygon([(12,2),(21,6),(19,17),(12,22),(5,17),(3,6)],fill=INK)
    p.polygon([(12,4),(18,7),(17,16),(12,19),(7,16),(6,7)],fill=c)
    p.line((12,6,12,18),fill=PAPER,width=2);p.line((8,11,16,11),fill=PAPER,width=2)

def science(p,c):
    p.rectangle((9,2,15,4),fill=INK);p.rectangle((11,4,13,10),fill=INK)
    p.polygon([(10,10),(4,19),(6,22),(18,22),(20,19),(14,10)],fill=INK)
    p.polygon([(8,18),(11,12),(13,12),(16,18)],fill=PAPER)
    p.polygon([(7,18),(17,18),(18,20),(6,20)],fill=c)
    p.point((11,17),fill=INK);p.point((15,19),fill=PAPER)

def culture(p,c):
    p.polygon([(3,5),(10,4),(12,6),(14,4),(21,5),(21,19),(14,18),(12,20),(10,18),(3,19)],fill=INK)
    p.polygon([(5,7),(10,6),(11,8),(11,17),(5,16)],fill=PAPER)
    p.polygon([(13,8),(14,6),(19,7),(19,16),(13,17)],fill=c)
    p.line((7,10,10,10),fill=c,width=2);p.line((15,10,18,10),fill=PAPER,width=2)

def energy(p,c):
    p.polygon([(13,2),(5,13),(11,13),(8,22),(20,9),(14,9),(17,2)],fill=INK)
    p.polygon([(13,4),(8,11),(13,11),(11,18),(17,10),(12,10),(15,4)],fill=c)
    p.rectangle((2,18,4,20),fill=c);p.rectangle((20,3,22,5),fill=c)

def research(p,c):
    p.rectangle((4,4,18,19),fill=INK);p.rectangle((6,6,16,17),fill=PAPER)
    p.line((8,9,14,9),fill=c,width=2);p.line((8,13,12,13),fill=c,width=2)
    p.polygon([(17,14),(20,17),(17,20),(14,17)],fill=c)
    p.rectangle((3,19,19,21),fill=INK)

def choice(p,c):
    p.polygon([(12,2),(22,12),(12,22),(2,12)],fill=INK)
    p.polygon([(12,5),(19,12),(12,19),(5,12)],fill=c)
    p.polygon([(12,7),(15,12),(12,17),(9,12)],fill=PAPER)
    p.rectangle((11,1,13,5),fill=PAPER)

for name,color,drawer in [
    ('hall','#d0a66e',hall),('governance','#d0a66e',governance),
    ('production','#df936e',production),('trade','#68c4ac',trade),
    ('infrastructure','#8cb7e8',infrastructure),('defense','#e28a91',defense),
    ('science','#b29ae5',science),('culture','#e2afd3',culture),
    ('energy','#e1d07e',energy),('research','#8cd1dc',research),
    ('choice','#efca78',choice)]:icon(name,color,drawer)
print('Built 11 city-tree emblems')
