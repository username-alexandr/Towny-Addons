package cc.crafto.ui.client;
import com.google.gson.*;
import java.nio.file.*;
public final class ThemePreviewProbe {
 public static void main(String[] args)throws Exception{
  Path out=Path.of(args[0]);JsonObject palette=JsonParser.parseString(Files.readString(Path.of(args[1]))).getAsJsonObject();
  for(int[] size:new int[][]{{871,447},{520,340},{320,180}})for(String section:new String[]{"settings","settings-tree","settings-hud"}){
   var c=PanelProbe.client(palette);c.settings.themeMode="light";
   var screen=PanelProbe.setup(c,size[0],size[1],section);
   PanelProbe.render(screen,out.resolve("light-"+section+"-"+size[0]+"x"+size[1]+".png"));
  }
  System.out.println("PASS 9 light-palette settings renders; AWT adapter, no game runtime");
 }
}
