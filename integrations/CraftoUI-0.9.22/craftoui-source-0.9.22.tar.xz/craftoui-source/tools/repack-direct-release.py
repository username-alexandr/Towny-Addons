#!/usr/bin/env python3
"""Package a full direct javac compilation against the previous release's resource layout.

The source tree's Gradle build is preferred when its distribution is reachable.
This preserves the nested MixinExtras jar and generated manifests from the
previous release while replacing *every* compiled project class with fresh code.
"""
from pathlib import Path
import re
import sys
import zipfile

root = Path(__file__).resolve().parents[1]
classes = root / 'build/direct/classes'
version = re.search(r'(?m)^version=(.+)$', (root / 'gradle.properties').read_text()).group(1)
client_version = re.search(r'(?m)^client_version=(.+)$', (root / 'gradle.properties').read_text()).group(1)
previous = '0.9.10'
for kind, name in [('Fabric',f'CraftoUI-Fabric-26.2-{previous}.jar'),('Folia',f'CraftoUI-Folia-26.2-{previous}.jar'),('API',f'CraftoUI-API-{previous}.jar')]:
    if kind != 'Folia' and client_version != version:
        continue  # A server-only release retains the previous client and API artifacts.
    source = root / 'tools' / 'build-baseline' / name
    target_version = client_version if kind == 'Fabric' else version
    target = root / 'jars' / name.replace(previous,target_version)
    added = ['cc/crafto/ui/CityTreeLayout.class','cc/crafto/ui/CityTreeLayout$Node.class','cc/crafto/ui/CityTreeLayout$Point.class']
    if kind == 'Fabric': added.append('cc/crafto/ui/client/CityTreeCanvas.class')
    if kind == 'Folia': added.extend(['cc/crafto/ui/server/CitySpecialization.class','cc/crafto/ui/server/CitySpecialization$Profile.class','cc/crafto/ui/server/CitySpecialization$Snapshot.class'])
    with zipfile.ZipFile(source) as old,zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as new:
        original = set(old.namelist())
        for entry in old.infolist():
            data = old.read(entry.filename)
            if entry.filename.endswith('.class'):
                path = classes / entry.filename
                if not path.is_file(): raise SystemExit(f'Missing compiled class: {path}')
                data = path.read_bytes()
            if kind == 'Fabric' and entry.filename == 'fabric.mod.json':
                data = data.replace(previous.encode(),client_version.encode())
            if kind == 'Folia' and entry.filename == 'plugin.yml':
                data = data.replace(f"version: '{previous}'".encode(),f"version: '{version}'".encode())
            new.writestr(entry,data)
        for entry in added:
            if entry not in original:
                path=classes/entry
                if not path.is_file(): raise SystemExit(f'Missing compiled class: {path}')
                new.writestr(entry,path.read_bytes())
    print(target,'classes:',sum(1 for n in zipfile.ZipFile(target).namelist() if n.endswith('.class')))
