package cc.crafto.ui;

import java.util.*;

/** Deterministic, evenly spaced progression rings centred on the town hall. */
public final class CityTreeLayout {
    public record Node(String id,String category,List<String> parents){}
    public record Point(double x,double y,int tier){}
    private static final String HALL="building:town_hall";
    private static final double RING_GAP=230,MIN_ARC=190;
    private static final List<String> SECTORS=List.of("Управление","Производство","Торговля","Инфраструктура","Оборона","Наука","Культура","Энергия","Исследования");
    private CityTreeLayout(){}

    public static Map<String,Point> arrange(List<Node> nodes){
        var byId=new TreeMap<String,Node>();for(Node node:nodes)byId.put(node.id(),node);
        var depths=new HashMap<String,Integer>();for(String id:byId.keySet())depth(id,byId,depths,new HashSet<>());
        var ordered=new ArrayList<>(byId.values());ordered.removeIf(node->node.id().equals(HALL));
        ordered.sort(Comparator.comparingInt((Node node)->depths.getOrDefault(node.id(),0))
            .thenComparingInt(node->categoryIndex(node.category())).thenComparing(Node::id));
        var rings=new TreeMap<Integer,List<Node>>();var assigned=new HashMap<String,Integer>();
        if(byId.containsKey(HALL))assigned.put(HALL,0);
        for(Node node:ordered){
            int first=Math.max(1,depths.getOrDefault(node.id(),0));
            for(String parent:node.parents())if(assigned.containsKey(parent))first=Math.max(first,assigned.get(parent)+1);
            int ring=first;
            while(rings.getOrDefault(ring,List.of()).size()>=capacity(ring))ring++;
            rings.computeIfAbsent(ring,ignored->new ArrayList<>()).add(node);
            assigned.put(node.id(),ring);
        }
        var result=new LinkedHashMap<String,Point>();if(byId.containsKey(HALL))result.put(HALL,new Point(0,0,0));
        for(var entry:rings.entrySet()){
            int ring=entry.getKey();var group=entry.getValue();
            group.sort(Comparator.comparingDouble((Node node)->(targetAngle(node,result)+Math.PI/2+2*Math.PI)%(2*Math.PI))
                .thenComparing(Node::id));
            int count=group.size();double sin=0,cos=0;
            for(int i=0;i<count;i++){
                double desired=targetAngle(group.get(i),result)-2*Math.PI*i/count;
                sin+=Math.sin(desired);cos+=Math.cos(desired);
            }
            double radius=RING_GAP*ring,phase=Math.atan2(sin,cos);
            for(int i=0;i<count;i++){
                double angle=phase+2*Math.PI*i/count;
                result.put(group.get(i).id(),new Point(Math.cos(angle)*radius,Math.sin(angle)*radius,ring));
            }
        }
        return Map.copyOf(result);
    }
    private static int capacity(int ring){return Math.max(1,(int)Math.floor(2*Math.PI*RING_GAP*ring/MIN_ARC));}
    private static int categoryIndex(String category){int index=SECTORS.indexOf(category);return index<0?SECTORS.size():index;}
    private static double targetAngle(Node node,Map<String,Point> placed){
        for(String parent:node.parents()){
            Point point=placed.get(parent);
            if(point!=null&&point.tier()>0)return Math.atan2(point.y(),point.x());
        }
        return -Math.PI/2+2*Math.PI*(categoryIndex(node.category())+.5)/SECTORS.size();
    }
    private static int depth(String id,Map<String,Node> nodes,Map<String,Integer> done,Set<String> visiting){
        if(done.containsKey(id))return done.get(id);
        if(!visiting.add(id))return 0;
        Node node=nodes.get(id);int tier=0;
        if(node!=null)for(String parent:node.parents())if(nodes.containsKey(parent))tier=Math.max(tier,1+depth(parent,nodes,done,visiting));
        visiting.remove(id);done.put(id,Math.min(16,tier));return done.get(id);
    }
}
