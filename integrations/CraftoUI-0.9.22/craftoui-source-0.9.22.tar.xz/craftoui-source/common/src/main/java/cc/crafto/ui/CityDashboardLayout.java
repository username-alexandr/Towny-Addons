package cc.crafto.ui;

/** Logical GUI pixels, independent of window resolution and Minecraft GUI Scale. */
public record CityDashboardLayout(int width, int viewport, int metricColumns, int shortcutColumns,
                                  int cardColumns, int metricsY, int shortcutsY, int tabsY,
                                  int cardsY, int contentHeight, int capacity,
                                  int financeY,int financeColumns,int financeCount,int developmentCount,
                                  boolean dense,int metricHeight,int shortcutHeight,int cardHeight,int gap) {
    public static final int GAP=8, METRIC_HEIGHT=50, SHORTCUT_HEIGHT=30, CARD_HEIGHT=68;
    public record Box(int x,int y,int width,int height) {
        public int right(){return x+width;} public int bottom(){return y+height;}
    }
    public static CityDashboardLayout fit(int width,int viewport,int shortcutCount,int rows){
        return fit(width,viewport,shortcutCount,rows,0);
    }
    public static CityDashboardLayout fit(int width,int viewport,int shortcutCount,int rows,int financeCount){
        return fit(width,viewport,shortcutCount,rows,financeCount,3);
    }
    public static CityDashboardLayout fit(int width,int viewport,int shortcutCount,int rows,int financeCount,int developmentCount){
        width=Math.max(120,width);viewport=Math.max(1,viewport);
        financeCount=Math.clamp(financeCount,0,3);
        developmentCount=Math.clamp(developmentCount,0,shortcutCount);
        int metrics=width>=500?4:2,shortcuts=developmentCount==4?(width>=500?4:2):(width>=440?3:2),cards=width>=620?3:width>=360?2:1;
        boolean dense=width>=500&&viewport>=238;
        int metricHeight=dense?32:METRIC_HEIGHT,shortcutHeight=dense?24:SHORTCUT_HEIGHT,cardHeight=dense?30:CARD_HEIGHT,gap=dense?6:GAP;
        int my=dense?15:28,sy=my+(dense?15:16)+(4+metrics-1)/metrics*(metricHeight+(dense?0:gap));
        int financeColumns=width>=440?3:1,fy=sy+4;
        if(financeCount>0){
            fy=dense?my+metricHeight+15:fy;
            sy=fy+(financeCount+financeColumns-1)/financeColumns*(metricHeight+(dense?0:gap))+(dense?15:16);
        }else if(dense)sy=my+metricHeight+15;
        int secondColumns=width>=(developmentCount==4?500:620)?4:2;
        int developmentRows=(developmentCount+shortcuts-1)/shortcuts,managementRows=(Math.max(0,shortcutCount-developmentCount)+secondColumns-1)/secondColumns;
        int managementY=sy+developmentRows*(shortcutHeight+gap)+(dense?9:20);
        int ty=managementY+managementRows*(shortcutHeight+gap)+(dense?2:8),cy=ty+(dense?29:34);
        int capacity=Math.clamp(Math.max(1,(viewport-cy+gap)/(cardHeight+gap))*cards,1,12);
        int renderedRows=Math.max(1,(rows+cards-1)/cards);
        int content=cy+renderedRows*cardHeight+(renderedRows-1)*gap;
        return new CityDashboardLayout(width,viewport,metrics,shortcuts,cards,my,sy,ty,cy,content,capacity,fy,financeColumns,financeCount,developmentCount,dense,metricHeight,shortcutHeight,cardHeight,gap);
    }
    private Box cell(int index,int columns,int top,int height){int w=(width-(columns-1)*gap)/columns;return new Box(index%columns*(w+gap),top+index/columns*(height+gap),w,height);}
    public Box metric(int i){return cell(i,metricColumns,metricsY,metricHeight);}
    public Box finance(int i){return cell(i,financeColumns,financeY,metricHeight);}
    public int managementY(){return shortcutsY+(developmentCount+shortcutColumns-1)/shortcutColumns*(shortcutHeight+gap)+(dense?9:20);}
    public Box shortcut(int i){return i<developmentCount?cell(i,shortcutColumns,shortcutsY,shortcutHeight):cell(i-developmentCount,width>=(developmentCount==4?500:620)?4:2,managementY(),shortcutHeight);}
    public Box tab(int i){return cell(i,3,tabsY,dense?22:24);}
    public Box card(int i){return cell(i,cardColumns,cardsY,cardHeight);}
    public int maxScroll(){return Math.max(0,contentHeight-viewport);}
    public int scrollToReveal(int scroll,Box box){
        int value=scroll;if(box.y()<value)value=box.y();else if(box.bottom()>value+viewport)value=box.bottom()-viewport;
        return Math.clamp(value,0,maxScroll());
    }
}
