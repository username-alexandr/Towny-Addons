package cc.crafto.ui;

import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class CityTreeLayoutTest {
    @Test void rootAndDependentBranchesHaveStableWorldCoordinates(){
        var nodes=List.of(new CityTreeLayout.Node("building:town_hall","Управление",List.of()),new CityTreeLayout.Node("building:forge","Производство",List.of("building:town_hall")),new CityTreeLayout.Node("building:foundry","Производство",List.of("building:forge")),new CityTreeLayout.Node("research:metallurgy","Исследования",List.of("building:foundry")));
        var graph=CityTreeLayout.arrange(nodes);
        assertEquals(0,graph.get("building:town_hall").x());assertEquals(0,graph.get("building:town_hall").y());
        assertEquals(1,graph.get("building:forge").tier());assertEquals(2,graph.get("building:foundry").tier());assertEquals(3,graph.get("research:metallurgy").tier());
        assertEquals(graph,CityTreeLayout.arrange(nodes));
    }
    @Test void crowdedBranchesDoNotCoverOtherNodes(){
        var nodes=new ArrayList<CityTreeLayout.Node>();nodes.add(new CityTreeLayout.Node("building:town_hall","Управление",List.of()));
        for(int i=0;i<35;i++)nodes.add(new CityTreeLayout.Node("building:branch_"+i,"Производство",List.of("building:town_hall")));
        var graph=CityTreeLayout.arrange(nodes);assertEquals(nodes.size(),graph.size());
        var points=new ArrayList<>(graph.values());for(int i=0;i<points.size();i++)for(int j=i+1;j<points.size();j++)
            assertTrue(Math.hypot(points.get(i).x()-points.get(j).x(),points.get(i).y()-points.get(j).y())>=58);
    }
    @Test void deeperNodesGrowOutOfTheirRealParentBranch(){
        var nodes=List.of(
            new CityTreeLayout.Node("building:town_hall","Управление",List.of()),
            new CityTreeLayout.Node("building:forge","Производство",List.of("building:town_hall")),
            new CityTreeLayout.Node("building:market","Торговля",List.of("building:town_hall")),
            new CityTreeLayout.Node("building:foundry","Производство",List.of("building:forge")));
        var points=CityTreeLayout.arrange(nodes);
        var forge=points.get("building:forge");var market=points.get("building:market");var foundry=points.get("building:foundry");
        assertTrue(Math.hypot(foundry.x()-forge.x(),foundry.y()-forge.y())<Math.hypot(foundry.x()-market.x(),foundry.y()-market.y()));
        assertTrue(Math.hypot(foundry.x(),foundry.y())>Math.hypot(forge.x(),forge.y()));
    }
}
