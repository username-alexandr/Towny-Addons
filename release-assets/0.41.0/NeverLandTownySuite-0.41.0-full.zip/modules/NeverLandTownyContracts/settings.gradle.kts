rootProject.name = "NeverLandTownyContracts"
