package ru.neverland.townybuilds.integration;

import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;

public final class ItemsAdderHook {
    private final JavaPlugin plugin;
    private boolean available;
    private Method getInstance;
    private Method getItemStack;

    public ItemsAdderHook(JavaPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() { synchronized (ru.neverland.core.SuiteState.lock()) {
        available = false;
        if (!plugin.getConfig().getBoolean("settings.itemsadder.enabled", true)
                || Bukkit.getPluginManager().getPlugin("ItemsAdder") == null) {
            return;
        }
        try {
            Class<?> customStack = Class.forName("dev.lone.itemsadder.api.CustomStack");
            getInstance = customStack.getMethod("getInstance", String.class);
            getItemStack = customStack.getMethod("getItemStack");
            available = true;
            plugin.getLogger().info("ItemsAdder обнаружен: пользовательские иконки GUI включены.");
        } catch (ReflectiveOperationException exception) {
            plugin.getLogger().warning("ItemsAdder обнаружен, но его API недоступен: " + exception.getMessage());
        }
    } }

    public boolean available() { synchronized (ru.neverland.core.SuiteState.lock()) {
        return available;
    } }

    public ItemStack item(String namespacedId, int amount) { synchronized (ru.neverland.core.SuiteState.lock()) {
        if (!available || namespacedId == null || namespacedId.isBlank()) {
            return null;
        }
        try {
            Object custom = getInstance.invoke(null, namespacedId);
            if (custom == null) {
                return null;
            }
            ItemStack item = ((ItemStack) getItemStack.invoke(custom)).clone();
            item.setAmount(Math.max(1, amount));
            return item;
        } catch (ReflectiveOperationException | ClassCastException exception) {
            plugin.getLogger().warning("Не удалось получить предмет ItemsAdder " + namespacedId + ": " + exception.getMessage());
            return null;
        }
    } }
}
