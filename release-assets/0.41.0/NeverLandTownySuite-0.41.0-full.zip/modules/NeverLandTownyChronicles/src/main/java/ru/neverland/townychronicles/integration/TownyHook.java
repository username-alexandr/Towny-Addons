package ru.neverland.townychronicles.integration;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.TownyCommandAddonAPI;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;
import org.bukkit.command.CommandExecutor;
import org.bukkit.entity.Player;

import java.util.Collection;
import java.util.UUID;

public final class TownyHook {
    public Resident resident(Player player){ synchronized (ru.neverland.core.SuiteState.lock()) {return TownyAPI.getInstance().getResident(player);} }public Resident resident(UUID id){ synchronized (ru.neverland.core.SuiteState.lock()) {return TownyAPI.getInstance().getResident(id);} }
    public Town town(Player player){ synchronized (ru.neverland.core.SuiteState.lock()) {Resident resident=resident(player);return resident==null?null:resident.getTownOrNull();} }public Town townOf(UUID id){ synchronized (ru.neverland.core.SuiteState.lock()) {Resident resident=resident(id);return resident==null?null:resident.getTownOrNull();} }
    public Town town(UUID id){ synchronized (ru.neverland.core.SuiteState.lock()) {return TownyAPI.getInstance().getTown(id);} }public Town town(String name){ synchronized (ru.neverland.core.SuiteState.lock()) {return TownyAPI.getInstance().getTown(name);} }public Collection<Town> towns(){ synchronized (ru.neverland.core.SuiteState.lock()) {return TownyAPI.getInstance().getTowns();} }
    public boolean register(String name,CommandExecutor executor){ synchronized (ru.neverland.core.SuiteState.lock()) {return TownyCommandAddonAPI.addSubCommand(TownyCommandAddonAPI.CommandType.TOWN,name,executor);} }public void unregister(String name){ synchronized (ru.neverland.core.SuiteState.lock()) {TownyCommandAddonAPI.removeSubCommand(TownyCommandAddonAPI.CommandType.TOWN,name);} }
    public double balance(Town town){ synchronized (ru.neverland.core.SuiteState.lock()) {try{return town.getAccount().getHoldingBalance();}catch(RuntimeException exception){return 0;}} }
}
